package dev.dozyfj.pulsemessenger;

import static org.junit.Assert.*;
import org.json.JSONObject;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import java.io.IOException;
import java.net.InetAddress;
import java.nio.file.Files;
import java.security.KeyStore;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 28)
// Robolectric installs Conscrypt after @BeforeClass; use one provider for both sides of TLS.
@org.robolectric.annotation.ConscryptMode(org.robolectric.annotation.ConscryptMode.Mode.OFF)
public class PhoneServerTest {
    private static PhoneIdentity identity;
    @BeforeClass public static void certificate() throws Exception {
        var directory = Files.createTempDirectory("pulse-phone-tls-");
        var file = directory.resolve("test.p12");
        try {
            Process keytool = new ProcessBuilder(System.getProperty("java.home") + "/bin/keytool", "-genkeypair", "-alias", "phone", "-keyalg", "RSA", "-keysize", "2048",
                    "-storetype", "PKCS12", "-keystore", file.toString(), "-storepass", "synthetic-test-password", "-dname", "CN=Pulse test phone", "-validity", "2").redirectErrorStream(true).redirectOutput(directory.resolve("keytool.log").toFile()).start();
            assertTrue(keytool.waitFor(30, TimeUnit.SECONDS)); assertEquals(0, keytool.exitValue());
            KeyStore keys = KeyStore.getInstance("PKCS12");
            try (var input = Files.newInputStream(file)) { keys.load(input, "synthetic-test-password".toCharArray()); }
            identity = new PhoneIdentity(keys, "synthetic-test-password".toCharArray(), "phone");
        } finally { Files.deleteIfExists(file); Files.deleteIfExists(directory.resolve("keytool.log")); Files.deleteIfExists(directory); }
    }
    private static JSONObject credentials(String username) throws Exception { return new JSONObject().put("username", username).put("password", "test-password-123"); }
    private String base(PhoneServer server) { return "https://127.0.0.1:" + server.port() + "#sha256=" + identity.fingerprint; }
    @Test(timeout = 30_000) public void realTlsDeliveryIsolationReplayAndRestartKeepServerData() throws Exception {
        var context = RuntimeEnvironment.getApplication();
        context.deleteDatabase("pulse-host.db");
        PhoneServerStore host = new PhoneServerStore(context);
        PhoneServer server = new PhoneServer(host, identity, InetAddress.getLoopbackAddress(), 0); server.start();
        ChatStore cache = new ChatStore(context);
        try {
            String base = base(server);
            assertTrue(new PulseApi(base, null).request("/health", null).getBoolean("ok"));
            JSONObject alice = new PulseApi(base, null).request("/v1/register", credentials("alice"));
            JSONObject bob = new PulseApi(base, null).request("/v1/register", credentials("bob"));
            JSONObject eve = new PulseApi(base, null).request("/v1/register", credentials("eve"));
            assertEquals("alice", new PulseApi(base, null).request("/v1/login", credentials("alice")).getString("username"));
            PulseApi sender = new PulseApi(base, alice.getString("token")), recipient = new PulseApi(base, bob.getString("token"));
            String owner = base + "|alice";
            cache.queue(owner, "alice", "bob", "Phone TLS message", false);
            ChatStore.Message queued = cache.pending(owner).get(0);
            ChatStore.Message sent = sender.send(queued);
            assertEquals(sent.sequence(), sender.send(queued).sequence());
            cache.delivered(owner, "alice", sent);
            assertTrue(cache.pending(owner).isEmpty());
            assertEquals("Phone TLS message", recipient.fetch(0).get(0).text());
            assertTrue(recipient.fetch(sent.sequence()).isEmpty());
            assertTrue(new PulseApi(base, eve.getString("token")).fetch(0).isEmpty());
            try { sender.request("/v1/messages", new JSONObject().put("id", queued.id()).put("to", "bob").put("text", "Different")); fail(); }
            catch (PulseApi.ApiError error) { assertEquals(409, error.code); }
            int port = server.port(); server.close(); host.close();
            host = new PhoneServerStore(context);
            server = new PhoneServer(host, identity, InetAddress.getLoopbackAddress(), port); server.start();
            assertEquals(sent.sequence(), recipient.fetch(0).get(0).sequence());
            assertEquals(sent.sequence(), sender.send(queued).sequence());
            try (var cursor = host.getReadableDatabase().rawQuery("SELECT password FROM users WHERE name = 'alice'", null)) {
                assertTrue(cursor.moveToFirst()); assertNotEquals("test-password-123", cursor.getString(0));
            }
            try (var cursor = host.getReadableDatabase().rawQuery("SELECT hash FROM sessions", null)) {
                while (cursor.moveToNext()) assertNotEquals(alice.getString("token"), cursor.getString(0));
            }
        } finally { server.close(); host.close(); cache.close(); }
    }
    @Test public void certificatePinAndNormalHttpsTrustCannotBeBypassed() throws Exception {
        PhoneServerStore store = new PhoneServerStore(RuntimeEnvironment.getApplication());
        try (PhoneServer server = new PhoneServer(store, identity, InetAddress.getLoopbackAddress(), 0)) {
            server.start();
            String base = base(server);
            for (String address : new String[]{base.replace(identity.fingerprint, "0".repeat(64)), base.split("#")[0]}) {
                try { new PulseApi(address, null).request("/health", null); fail("Untrusted certificate accepted"); }
                catch (IOException expected) { }
            }
            assertTrue(new PulseApi(base, null).request("/health", null).getBoolean("ok"));
        } finally { store.close(); }
    }
    @Test public void inputAuthenticationAndAttemptLimitsAreEnforced() throws Exception {
        var context = RuntimeEnvironment.getApplication(); context.deleteDatabase("pulse-host.db");
        PhoneServerStore store = new PhoneServerStore(context);
        try (PhoneServer server = new PhoneServer(store, identity, InetAddress.getLoopbackAddress(), 0)) {
            server.start(); String base = base(server);
            PulseApi anonymous = new PulseApi(base, null);
            try { anonymous.fetch(0); fail(); } catch (PulseApi.ApiError e) { assertEquals(401, e.code); }
            JSONObject result = anonymous.request("/v1/register", credentials("alice"));
            PulseApi alice = new PulseApi(base, result.getString("token"));
            try { anonymous.request("/v1/register", credentials("alice")); fail(); } catch (PulseApi.ApiError e) { assertEquals(409, e.code); }
            try { anonymous.request("/v1/login", credentials("alice").put("password", "wrong-password")); fail(); } catch (PulseApi.ApiError e) { assertEquals(401, e.code); }
            try { alice.request("/v1/messages?after=-1", null); fail(); } catch (PulseApi.ApiError e) { assertEquals(400, e.code); }
            try { alice.request("/v1/messages", new JSONObject().put("to", "absent").put("id", UUID.randomUUID()).put("text", "hello")); fail(); } catch (PulseApi.ApiError e) { assertEquals(404, e.code); }
            try { alice.request("/v1/messages", new JSONObject().put("to", "bob").put("id", UUID.randomUUID()).put("text", "x".repeat(17_000))); fail(); } catch (PulseApi.ApiError e) { assertEquals(413, e.code); }
            for (int i = 0; i < 27; i++) {
                try { anonymous.request("/v1/login", credentials("bad").put("password", "short")); fail(); }
                catch (PulseApi.ApiError e) { assertEquals(400, e.code); }
            }
            try { anonymous.request("/v1/login", credentials("alice")); fail(); } catch (PulseApi.ApiError e) { assertEquals(429, e.code); }
        } finally { store.close(); }
    }
    @Test public void pairingLinksPreservePinAndRejectUnsafeSchemes() throws Exception {
        String link = "https://192.168.1.20:8443#sha256=" + identity.fingerprint;
        assertEquals(link, PulseApi.normalizeUrl(link));
        assertEquals("https://example.com", PulseApi.normalizeUrl(" https://example.com/ "));
        for (String input : new String[]{"http://192.168.1.20:8443", "https://example.com#sha256=oops", "http://localhost#sha256=" + identity.fingerprint, "https://user:pass@example.com", "https://example.com/path"}) {
            try { PulseApi.normalizeUrl(input); fail(input); } catch (IOException expected) { }
        }
    }
}
