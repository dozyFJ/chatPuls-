package dev.dozyfj.pulsemessenger;

import static org.junit.Assert.*;
import static org.robolectric.Shadows.shadowOf;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.Signature;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.security.MessageDigest;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 27)
public class UpdateClientTest {
    private static final String URL = UpdateClient.FEED + "releases/PulseMessenger-0.2.0.apk";
    private static final String HASH = "a".repeat(64);
    private String manifest(long code, String url, String hash) throws Exception {
        return new JSONObject().put("versionCode", code).put("versionName", "0.2.0").put("url", url).put("sha256", hash).toString();
    }
    @Test public void acceptsOnlyNewerVersionsFromTheDedicatedUpdateFeed() throws Exception {
        assertEquals(2, UpdateClient.parseManifest(manifest(2, URL, HASH), 1).code());
        assertNull(UpdateClient.parseManifest(manifest(2, URL, HASH), 2));
        for (String url : new String[]{"https://example.com/app.apk", UpdateClient.FEED + "../app.apk", UpdateClient.FEED + "releases/other.apk", URL + "?download=1"}) {
            try { UpdateClient.parseManifest(manifest(2, url, HASH), 1); fail("Accepted " + url); } catch (IOException expected) { }
        }
        try { UpdateClient.parseManifest(manifest(2, URL, "abc"), 1); fail(); } catch (IOException expected) { }
    }
    @Test public void verifiesChecksumPackageVersionAndSignatureBeforeInstall() throws Exception {
        Context context = RuntimeEnvironment.getApplication();
        PackageInfo installed = shadowOf(context.getPackageManager()).getInternalMutablePackageInfo(context.getPackageName());
        installed.versionCode = 1; installed.signatures = new Signature[]{new Signature("0011")};
        PackageInfo archive = new PackageInfo(); archive.packageName = context.getPackageName(); archive.versionCode = 2;
        archive.signatures = new Signature[]{new Signature("0011")};
        File directory = new File(context.getCacheDir(), "updates"); assertTrue(directory.mkdirs() || directory.isDirectory());
        File file = new File(directory, "test.apk"); Files.write(file.toPath(), new byte[]{1, 2, 3});
        shadowOf(context.getPackageManager()).setPackageArchiveInfo(file.getPath(), archive);
        StringBuilder hash = new StringBuilder();
        for (byte b : MessageDigest.getInstance("SHA-256").digest(new byte[]{1, 2, 3})) hash.append(String.format("%02x", b & 255));
        UpdateClient.Update update = new UpdateClient.Update(2, "0.2.0", URL, hash.toString());
        UpdateClient client = new UpdateClient(context);
        client.verifyReady(file, update);
        Files.write(file.toPath(), new byte[]{4});
        try { client.verifyReady(file, update); fail("Tampering was accepted"); } catch (IOException expected) { }
        Files.write(file.toPath(), new byte[]{1, 2, 3});
        archive.signatures = new Signature[]{new Signature("0022")};
        try { client.verifyReady(file, update); fail("A different signer was accepted"); } catch (IOException expected) { }
        archive.signatures = installed.signatures;
        archive.packageName = "another.app";
        assertFalse(UpdateClient.validPackage(archive, installed, context.getPackageName(), 2));
        archive.packageName = context.getPackageName();
        archive.versionCode = 1;
        assertFalse(UpdateClient.validPackage(archive, installed, context.getPackageName(), 1));
    }
}
