package dev.dozyfj.pulsemessenger;

import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import java.util.List;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 28)
public class ChatStoreTest {
    @Test public void pendingAckDoesNotSkipIncomingMessagesAndAccountsAreSeparate() {
        ChatStore store = new ChatStore(RuntimeEnvironment.getApplication());
        String owner = "https://example.test|alice";
        store.queue(owner, "alice", "bob", "queued", false);
        ChatStore.Message pending = store.pending(owner).get(0);
        assertEquals(1, pending.status());
        store.delivered(owner, "alice", new ChatStore.Message(pending.id(), "alice", "bob", "queued", 200, 2, 0));
        assertEquals(0, store.cursor(owner));
        store.received(owner, "alice", List.of(new ChatStore.Message("incoming", "bob", "alice", "earlier", 100, 1, 0),
                new ChatStore.Message(pending.id(), "alice", "bob", "queued", 200, 2, 0)));
        assertEquals(2, store.cursor(owner));
        assertEquals(2, store.messages(owner, "alice", "bob").size());
        assertTrue(store.pending(owner).isEmpty());
        assertTrue(store.chats("local").isEmpty());
        store.close();
    }
    @Test public void offlineMessagesRemainLocalAndFailedMessagesCanRetry() {
        ChatStore store = new ChatStore(RuntimeEnvironment.getApplication());
        store.queue("local", "я", "bob", "local note", true);
        assertTrue(store.pending("local").isEmpty());
        assertEquals(3, store.messages("local", "я", "bob").get(0).status());
        String owner = "https://example.test|alice";
        store.queue(owner, "alice", "bob", "hello", false);
        ChatStore.Message message = store.pending(owner).get(0);
        store.markFailed(owner, message);
        assertTrue(store.pending(owner).isEmpty());
        store.retry(owner, message);
        assertEquals(1, store.pending(owner).size());
        store.removeUnsent(owner, message);
        assertTrue(store.pending(owner).isEmpty());
        store.close();
    }
    @Test public void urlRequiresHttpsOutsideLocalDevelopment() throws Exception {
        assertEquals("https://example.org", PulseApi.normalizeUrl("https://example.org/"));
        assertEquals("http://10.0.2.2:3000", PulseApi.normalizeUrl("http://10.0.2.2:3000"));
        for (String invalid : List.of("http://example.org", "https://user@example.org", "https://example.org/path", "https://example.org?q=1")) {
            try { PulseApi.normalizeUrl(invalid); fail("Accepted " + invalid); } catch (java.io.IOException expected) { }
        }
    }
    @Test public void filtersIncomingAndArchivesWithoutDeletingMessages() {
        ChatStore store = new ChatStore(RuntimeEnvironment.getApplication());
        String owner = "https://example.test|alice";
        store.createChat(owner, "bob"); store.createChat(owner, "carol");
        store.received(owner, "alice", List.of(new ChatStore.Message("msg1", "bob", "alice", "hello", 100, 1, 0)));
        assertEquals(List.of("bob"), store.chats(owner, "alice", ChatStore.INCOMING));
        store.setArchived(owner, "bob", true);
        assertEquals(List.of("bob"), store.chats(owner, "alice", ChatStore.ARCHIVED));
        assertFalse(store.chats(owner, "alice", ChatStore.ALL).contains("bob"));
        assertTrue(store.chats(owner, "alice", ChatStore.INCOMING).isEmpty());
        assertEquals(1, store.messages(owner, "alice", "bob").size());
        assertTrue(store.chats(owner).contains("bob"));
        store.setArchived(owner, "bob", false);
        assertEquals(List.of("bob"), store.chats(owner, "alice", ChatStore.INCOMING));
        store.close();
    }
    @Test public void versionOneDatabaseMigratesWithoutLosingChatsOrMessages() {
        Context context = RuntimeEnvironment.getApplication(); context.deleteDatabase("pulse.db");
        java.io.File file = context.getDatabasePath("pulse.db"); file.getParentFile().mkdirs();
        SQLiteDatabase old = SQLiteDatabase.openOrCreateDatabase(file, null);
        old.execSQL("CREATE TABLE chats (owner TEXT NOT NULL, peer TEXT NOT NULL, touched INTEGER NOT NULL, PRIMARY KEY(owner, peer))");
        old.execSQL("CREATE TABLE messages (owner TEXT NOT NULL, sender TEXT NOT NULL, id TEXT NOT NULL, recipient TEXT NOT NULL, body TEXT NOT NULL, created INTEGER NOT NULL, sequence INTEGER NOT NULL DEFAULT 0, pending INTEGER NOT NULL, PRIMARY KEY(owner, sender, id))");
        old.execSQL("CREATE TABLE cursors (owner TEXT PRIMARY KEY, sequence INTEGER NOT NULL)");
        old.execSQL("INSERT INTO chats VALUES ('local', 'bob', 1)");
        old.execSQL("INSERT INTO messages VALUES ('local', 'bob', 'msg1', 'alice', 'hello', 1, 1, 0)");
        old.execSQL("INSERT INTO cursors VALUES ('local', 1)");
        old.setVersion(1); old.close();
        ChatStore store = new ChatStore(context);
        assertEquals(List.of("bob"), store.chats("local", "alice", ChatStore.INCOMING));
        assertEquals(1, store.messages("local", "alice", "bob").size());
        assertEquals(1, store.cursor("local"));
        assertFalse(store.isArchived("local", "bob"));
        store.setArchived("local", "bob", true);
        assertEquals(List.of("bob"), store.chats("local", "alice", ChatStore.ARCHIVED));
        store.close();
    }
}
