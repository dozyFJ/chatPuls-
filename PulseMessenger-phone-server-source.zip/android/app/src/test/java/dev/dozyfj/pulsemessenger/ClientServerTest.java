package dev.dozyfj.pulsemessenger;

import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import org.json.JSONObject;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.TimeUnit;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 28)
public class ClientServerTest {
    @Test public void offlineQueueReplaysToRealServerAndSynchronizesBetweenAccounts() throws Exception {
        Path directory = Files.createTempDirectory("pulse-integration-");
        int port;
        try (ServerSocket socket = new ServerSocket(0)) { port = socket.getLocalPort(); }
        String base = "http://127.0.0.1:" + port;
        Process server = null;
        ChatStore store = new ChatStore(RuntimeEnvironment.getApplication());
        try {
            server = start(directory, port);
            awaitReady(base, server);
            JSONObject alice = new PulseApi(base, null).request("/v1/register", new JSONObject().put("username", "alice").put("password", "password-123"));
            JSONObject bob = new PulseApi(base, null).request("/v1/register", new JSONObject().put("username", "bob").put("password", "password-123"));
            PulseApi aliceApi = new PulseApi(base, alice.getString("token"));
            PulseApi bobApi = new PulseApi(base, bob.getString("token"));
            String owner = base + "|alice";
            stop(server); server = null;
            store.queue(owner, "alice", "bob", "offline hello", false);
            ChatStore.Message queued = store.pending(owner).get(0);
            try { aliceApi.send(queued); fail("Offline send should fail"); } catch (IOException expected) { }
            assertEquals(1, store.pending(owner).size());
            server = start(directory, port);
            awaitReady(base, server);
            ChatStore.Message sent = aliceApi.send(queued);
            assertEquals(sent.sequence(), aliceApi.send(queued).sequence());
            store.delivered(owner, "alice", sent);
            List<ChatStore.Message> received = bobApi.fetch(0);
            assertEquals(1, received.size());
            assertEquals("offline hello", received.get(0).text());
            store.received(base + "|bob", "bob", received);
            assertEquals(1, store.messages(base + "|bob", "bob", "alice").size());
            assertTrue(bobApi.fetch(received.get(0).sequence()).isEmpty());
            assertTrue(store.pending(owner).isEmpty());
        } finally {
            if (server != null) stop(server);
            store.close();
            try (var paths = Files.walk(directory)) { paths.sorted(Comparator.reverseOrder()).forEach(path -> { try { Files.deleteIfExists(path); } catch (IOException ignored) { } }); }
        }
    }
    private Process start(Path directory, int port) throws IOException {
        ProcessBuilder builder = new ProcessBuilder("node", System.getProperty("pulse.server.file"));
        builder.environment().put("PULSE_DATA", directory.resolve("data.json").toString());
        builder.environment().put("PORT", Integer.toString(port));
        builder.redirectErrorStream(true); builder.redirectOutput(directory.resolve("server.log").toFile());
        return builder.start();
    }
    private void awaitReady(String base, Process server) throws Exception {
        for (int i = 0; i < 100; i++) {
            if (!server.isAlive()) throw new IOException("Server did not start");
            try {
                HttpURLConnection connection = (HttpURLConnection) new URL(base + "/health").openConnection();
                connection.setConnectTimeout(200); connection.setReadTimeout(200);
                try { if (connection.getResponseCode() == 200) return; } finally { connection.disconnect(); }
            } catch (IOException ignored) { }
            Thread.sleep(50);
        }
        throw new IOException("Server startup timed out");
    }
    private void stop(Process server) throws Exception {
        server.destroy();
        if (!server.waitFor(3, TimeUnit.SECONDS)) { server.destroyForcibly(); server.waitFor(); }
    }
}
