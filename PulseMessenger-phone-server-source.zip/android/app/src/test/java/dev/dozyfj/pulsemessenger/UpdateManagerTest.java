package dev.dozyfj.pulsemessenger;

import static org.junit.Assert.*;
import static org.robolectric.Shadows.shadowOf;
import android.os.Looper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.LooperMode;
import java.io.File;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 27)
@LooperMode(LooperMode.Mode.PAUSED)
public class UpdateManagerTest {
    @Test public void checksAndDownloadsOnceOffersOnceAndVerifiesBeforeInstall() throws Exception {
        CountDownLatch started = new CountDownLatch(1), release = new CountDownLatch(1);
        AtomicInteger checks = new AtomicInteger(), downloads = new AtomicInteger(), verifies = new AtomicInteger();
        UpdateClient.Update update = new UpdateClient.Update(2, "0.2.0", "url", "hash");
        File file = new File("update.apk");
        UpdateManager.Source source = new UpdateManager.Source() {
            public UpdateClient.Update check() throws Exception { checks.incrementAndGet(); started.countDown(); release.await(); return update; }
            public File download(UpdateClient.Update value) { downloads.incrementAndGet(); return file; }
            public void verifyReady(File result, UpdateClient.Update value) { verifies.incrementAndGet(); }
        };
        UpdateManager manager = new UpdateManager(source);
        manager.checkIfNeeded(); assertTrue(started.await(2, TimeUnit.SECONDS));
        manager.check(); assertEquals(1, checks.get()); release.countDown();
        await(() -> manager.phase() == UpdateManager.Phase.READY);
        assertEquals(1, downloads.get()); assertTrue(manager.takeOffer()); assertFalse(manager.takeOffer());
        AtomicReference<File> installed = new AtomicReference<>();
        manager.verify(installed::set, () -> fail("Verification failed"));
        await(() -> installed.get() != null);
        assertEquals(file, installed.get()); assertEquals(1, verifies.get());
    }
    @Test public void returningToAppChecksAgainAfterAnErrorOrCurrentVersion() throws Exception {
        AtomicInteger checks = new AtomicInteger();
        UpdateManager manager = new UpdateManager(new UpdateManager.Source() {
            public UpdateClient.Update check() throws Exception {
                if (checks.incrementAndGet() == 1) throw new java.io.IOException("offline");
                return null;
            }
            public File download(UpdateClient.Update value) { throw new AssertionError(); }
            public void verifyReady(File file, UpdateClient.Update value) { throw new AssertionError(); }
        });
        manager.checkIfNeeded(); await(() -> manager.phase() == UpdateManager.Phase.ERROR);
        manager.checkIfNeeded(); await(() -> manager.phase() == UpdateManager.Phase.CURRENT);
        manager.checkIfNeeded(); await(() -> checks.get() == 3 && manager.phase() == UpdateManager.Phase.CURRENT);
    }
    @Test public void verificationFailureNeverOffersTheFileForInstallation() throws Exception {
        UpdateClient.Update update = new UpdateClient.Update(2, "0.2.0", "url", "hash");
        UpdateManager manager = new UpdateManager(new UpdateManager.Source() {
            public UpdateClient.Update check() { return update; }
            public File download(UpdateClient.Update value) { return new File("update.apk"); }
            public void verifyReady(File file, UpdateClient.Update value) throws Exception { throw new java.io.IOException("tampered"); }
        });
        manager.check(); await(() -> manager.phase() == UpdateManager.Phase.READY);
        AtomicInteger failures = new AtomicInteger();
        manager.verify(file -> fail("Invalid APK must not be installed"), failures::incrementAndGet);
        await(() -> failures.get() == 1);
        assertEquals(UpdateManager.Phase.ERROR, manager.phase());
        assertFalse(manager.takeOffer());
    }
    private void await(java.util.function.BooleanSupplier condition) throws Exception {
        for (int i = 0; i < 200; i++) {
            shadowOf(Looper.getMainLooper()).idle();
            if (condition.getAsBoolean()) return;
            Thread.sleep(10);
        }
        fail("Timed out waiting for update");
    }
}
