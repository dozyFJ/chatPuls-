package dev.dozyfj.pulsemessenger;

import static org.junit.Assert.*;
import static org.robolectric.Shadows.shadowOf;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;
import android.app.AlertDialog;
import android.os.Looper;
import android.graphics.drawable.GradientDrawable;
import android.widget.LinearLayout;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import org.robolectric.shadows.ShadowAlertDialog;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 28)
public class MainActivityTest {
    @Test public void localChatAndDockWorkWithoutNetwork() {
        var controller = Robolectric.buildActivity(MainActivity.class).setup();
        MainActivity activity = controller.get();
        View root = activity.getWindow().getDecorView();
        assertNotNull(find(root, "Локальный режим", false));
        assertHeaderFillsWidth(root, "Чаты");
        assertNotNull(find(root, "Все", false));
        assertNotNull(find(root, "Входящие", false));
        assertNotNull(find(root, "Архивные", false));
        View plus = find(root, "Новый чат", true); assertNotNull(plus); plus.performClick();
        shadowOf(Looper.getMainLooper()).idle();
        AlertDialog dialog = ShadowAlertDialog.getLatestAlertDialog(); assertNotNull(dialog);
        EditText name = first(dialog.getWindow().getDecorView(), EditText.class); assertNotNull(name);
        name.setText("bob"); dialog.getButton(AlertDialog.BUTTON_POSITIVE).performClick();
        assertNotNull(find(root, "bob", false));
        assertNotNull(find(root, "Назад к чатам", true));
        assertHeaderFillsWidth(root, "bob");
        EditText message = first(root, EditText.class); assertNotNull(message); message.setText("Текст");
        View send = find(root, "Отправить сообщение", true); assertNotNull(send); send.performClick();
        assertNotNull(find(root, "Текст", false));
        assertNotNull(find(root, "Только на устройстве", false));
        find(root, "Настройки", true).performClick();
        assertNotNull(find(root, "Тёмная тема", false));
        assertHeaderFillsWidth(root, "Настройки");
        assertNotNull(find(root, "Запустить сервер", false));
        assertNotNull(find(root, "Настройки", false));
        assertNotNull(find(root, "Проверить обновления", true));
        find(root, "Контакты", true).performClick();
        assertNotNull(find(root, "bob", false));
        assertNotNull(find(root, "Создать чат", true));
        assertHeaderFillsWidth(root, "Контакты");
        assertNull(find(root, "Новый чат", true));
        find(root, "Лента", true).performClick();
        assertNotNull(find(root, "Лента пока не подключена.", false));
        assertHeaderFillsWidth(root, "Лента");
        assertTrue(find(root, "Стена", false).isSelected());
        find(root, "Новости", false).performClick();
        assertTrue(find(root, "Новости", false).isSelected());
        find(root, "Сообщества", false).performClick();
        assertTrue(find(root, "Сообщества", false).isSelected());
        assertNotNull(find(root, "Разделы ленты", true));
        assertNull(find(root, "Новый чат", true));
        find(root, "Чаты", true).performClick();
        View actions = find(root, "Действия чата bob", true); assertNotNull(actions); actions.performClick();
        AlertDialog archiveDialog = ShadowAlertDialog.getLatestAlertDialog();
        android.widget.ListView options = archiveDialog.getListView();
        options.performItemClick(options.getAdapter().getView(0, null, options), 0, options.getAdapter().getItemId(0));
        assertNull(find(root, "bob", false));
        find(root, "Архивные", false).performClick();
        assertNotNull(find(root, "bob", false));
        controller.pause().stop().destroy();
    }
    @Test public void dockIsFullWidthWithRoundIconsInBothThemes() {
        for (boolean dark : new boolean[]{false, true}) {
            org.robolectric.RuntimeEnvironment.getApplication().getSharedPreferences("pulse", 0).edit().putBoolean("dark", dark).commit();
            var controller = Robolectric.buildActivity(MainActivity.class).setup();
            View root = controller.get().getWindow().getDecorView();
            LinearLayout chats = (LinearLayout) find(root, "Чаты", true);
            assertNotNull(chats); assertTrue(chats.isSelected());
            View dock = (View) chats.getParent();
            assertEquals(ViewGroup.LayoutParams.MATCH_PARENT, dock.getLayoutParams().width);
            GradientDrawable icon = (GradientDrawable) chats.getChildAt(0).getBackground();
            assertEquals(GradientDrawable.OVAL, icon.getShape());
            assertNotNull(find(root, "Чаты", false));
            controller.pause().stop().destroy();
        }
    }
    private static void assertHeaderFillsWidth(View root, String title) {
        View heading = find(root, title, false);
        assertNotNull(heading);
        View header = (View) heading.getParent().getParent();
        ViewGroup.MarginLayoutParams params = (ViewGroup.MarginLayoutParams) header.getLayoutParams();
        assertEquals(ViewGroup.LayoutParams.MATCH_PARENT, params.width);
        assertEquals(0, params.leftMargin); assertEquals(0, params.rightMargin);
        assertEquals(0, params.topMargin);
    }
    private static View find(View root, String label, boolean description) {
        if (!root.isShown()) return null;
        CharSequence value = description ? root.getContentDescription() : root instanceof TextView ? ((TextView) root).getText() : null;
        if (value != null && label.contentEquals(value)) return root;
        if (root instanceof ViewGroup g) for (int i = 0; i < g.getChildCount(); i++) { View found = find(g.getChildAt(i), label, description); if (found != null) return found; }
        return null;
    }
    private static <T extends View> T first(View root, Class<T> type) {
        if (root.isShown() && type.isInstance(root)) return type.cast(root);
        if (root instanceof ViewGroup g) for (int i = 0; i < g.getChildCount(); i++) { T found = first(g.getChildAt(i), type); if (found != null) return found; }
        return null;
    }
}
