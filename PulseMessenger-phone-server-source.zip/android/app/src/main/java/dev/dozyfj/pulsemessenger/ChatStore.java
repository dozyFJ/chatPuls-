package dev.dozyfj.pulsemessenger;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

final class ChatStore extends SQLiteOpenHelper {
    static final int ALL = 0, INCOMING = 1, ARCHIVED = 2;
    record Message(String id, String from, String to, String text, long time, long sequence, int status) {}
    ChatStore(Context context) { super(context.getApplicationContext(), "pulse.db", null, 2); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE chats (owner TEXT NOT NULL, peer TEXT NOT NULL, touched INTEGER NOT NULL, archived INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(owner, peer))");
        db.execSQL("CREATE TABLE messages (owner TEXT NOT NULL, sender TEXT NOT NULL, id TEXT NOT NULL, recipient TEXT NOT NULL, body TEXT NOT NULL, created INTEGER NOT NULL, sequence INTEGER NOT NULL DEFAULT 0, pending INTEGER NOT NULL, PRIMARY KEY(owner, sender, id))");
        db.execSQL("CREATE TABLE cursors (owner TEXT PRIMARY KEY, sequence INTEGER NOT NULL)");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion == 1 && newVersion == 2) db.execSQL("ALTER TABLE chats ADD COLUMN archived INTEGER NOT NULL DEFAULT 0");
        else throw new IllegalStateException("Unsupported database version");
    }

    private void touch(SQLiteDatabase db, String owner, String peer, long time) {
        ContentValues values = new ContentValues();
        values.put("owner", owner); values.put("peer", peer); values.put("touched", time);
        db.insertWithOnConflict("chats", null, values, SQLiteDatabase.CONFLICT_IGNORE);
        db.execSQL("UPDATE chats SET touched = MAX(touched, ?) WHERE owner = ? AND peer = ?", new Object[]{time, owner, peer});
    }
    void createChat(String owner, String peer) { touch(getWritableDatabase(), owner, peer, System.currentTimeMillis()); }
    List<String> chats(String owner) {
        List<String> result = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery("SELECT peer FROM chats WHERE owner = ? ORDER BY touched DESC, peer", new String[]{owner})) {
            while (c.moveToNext()) result.add(c.getString(0));
        }
        return result;
    }
    List<String> chats(String owner, String user, int filter) {
        List<String> result = new ArrayList<>();
        String where = filter == ARCHIVED ? "archived = 1" : "archived = 0";
        if (filter == INCOMING) where += " AND EXISTS (SELECT 1 FROM messages m WHERE m.owner = chats.owner AND m.sender = chats.peer AND m.recipient = ?)";
        String[] args = filter == INCOMING ? new String[]{owner, user} : new String[]{owner};
        try (Cursor c = getReadableDatabase().rawQuery("SELECT peer FROM chats WHERE owner = ? AND " + where + " ORDER BY touched DESC, peer", args)) {
            while (c.moveToNext()) result.add(c.getString(0));
        }
        return result;
    }
    boolean isArchived(String owner, String peer) {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT archived FROM chats WHERE owner = ? AND peer = ?", new String[]{owner, peer})) {
            return c.moveToFirst() && c.getInt(0) != 0;
        }
    }
    void setArchived(String owner, String peer, boolean archived) {
        ContentValues v = new ContentValues(); v.put("archived", archived ? 1 : 0);
        getWritableDatabase().update("chats", v, "owner = ? AND peer = ?", new String[]{owner, peer});
    }
    void queue(String owner, String user, String peer, String text, boolean localOnly) {
        SQLiteDatabase db = getWritableDatabase();
        long now = System.currentTimeMillis();
        db.beginTransaction();
        try {
            touch(db, owner, peer, now);
            ContentValues v = new ContentValues();
            v.put("owner", owner); v.put("sender", user); v.put("id", UUID.randomUUID().toString());
            v.put("recipient", peer); v.put("body", text); v.put("created", now); v.put("sequence", 0); v.put("pending", localOnly ? 3 : 1);
            db.insertOrThrow("messages", null, v);
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }
    private Message fromCursor(Cursor c) {
        return new Message(c.getString(0), c.getString(1), c.getString(2), c.getString(3), c.getLong(4), c.getLong(5), c.getInt(6));
    }
    List<Message> pending(String owner) {
        List<Message> result = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery("SELECT id,sender,recipient,body,created,sequence,pending FROM messages WHERE owner = ? AND pending = 1 ORDER BY created,id", new String[]{owner})) {
            while (c.moveToNext()) result.add(fromCursor(c));
        }
        return result;
    }
    List<Message> messages(String owner, String user, String peer) {
        List<Message> result = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery("SELECT id,sender,recipient,body,created,sequence,pending FROM messages WHERE owner = ? AND ((sender = ? AND recipient = ?) OR (sender = ? AND recipient = ?)) ORDER BY created,sequence,id", new String[]{owner, user, peer, peer, user})) {
            while (c.moveToNext()) result.add(fromCursor(c));
        }
        return result;
    }
    void markFailed(String owner, Message message) {
        ContentValues values = new ContentValues(); values.put("pending", 2);
        getWritableDatabase().update("messages", values, "owner = ? AND sender = ? AND id = ? AND pending = 1", new String[]{owner, message.from(), message.id()});
    }
    void retry(String owner, Message message) {
        ContentValues values = new ContentValues(); values.put("pending", 1);
        getWritableDatabase().update("messages", values, "owner = ? AND sender = ? AND id = ? AND pending = 2", new String[]{owner, message.from(), message.id()});
    }
    void removeUnsent(String owner, Message message) {
        getWritableDatabase().delete("messages", "owner = ? AND sender = ? AND id = ? AND pending IN (1, 2)", new String[]{owner, message.from(), message.id()});
    }
    long cursor(String owner) {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT sequence FROM cursors WHERE owner = ?", new String[]{owner})) {
            return c.moveToFirst() ? c.getLong(0) : 0;
        }
    }
    private void storeDelivered(SQLiteDatabase db, String owner, String user, Message message) {
        String peer = message.from().equals(user) ? message.to() : message.from();
        touch(db, owner, peer, message.time());
        ContentValues v = new ContentValues();
        v.put("owner", owner); v.put("sender", message.from()); v.put("id", message.id());
        v.put("recipient", message.to()); v.put("body", message.text()); v.put("created", message.time());
        v.put("sequence", message.sequence()); v.put("pending", 0);
        db.insertWithOnConflict("messages", null, v, SQLiteDatabase.CONFLICT_REPLACE);
    }
    void delivered(String owner, String user, Message message) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try { storeDelivered(db, owner, user, message); db.setTransactionSuccessful(); }
        finally { db.endTransaction(); }
    }
    void received(String owner, String user, List<Message> messages) {
        if (messages.isEmpty()) return;
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            long cursor = cursor(owner);
            for (Message message : messages) {
                storeDelivered(db, owner, user, message);
                cursor = Math.max(cursor, message.sequence());
            }
            ContentValues v = new ContentValues(); v.put("owner", owner); v.put("sequence", cursor);
            db.insertWithOnConflict("cursors", null, v, SQLiteDatabase.CONFLICT_REPLACE);
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }
}
