package dev.dozyfj.pulsemessenger;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import java.net.InetAddress;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class PhoneServerService extends Service {
    private static final String STOP = "dev.dozyfj.pulsemessenger.STOP_HOST";
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private PhoneHost host;
    private PhoneServer server;
    private PhoneServerStore store;
    private PowerManager.WakeLock wake;
    private volatile boolean destroyed;
    @Override public void onCreate() {
        super.onCreate(); host = PhoneHost.get(this); host.attach(this);
        NotificationManager notifications = getSystemService(NotificationManager.class);
        notifications.createNotificationChannel(new NotificationChannel("phone-server", "Сервер на телефоне", NotificationManager.IMPORTANCE_LOW));
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stop = PendingIntent.getService(this, 1, new Intent(this, PhoneServerService.class).setAction(STOP), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification notification = new Notification.Builder(this, "phone-server").setSmallIcon(android.R.drawable.stat_notify_sync)
                .setContentTitle("Сервер Pulse включён").setContentText("Открыть Pulse или остановить сервер")
                .setContentIntent(open).setOngoing(true).addAction(new Notification.Action.Builder(null, "Остановить", stop).build()).build();
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(73, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE);
            else startForeground(73, notification);
            worker.execute(() -> {
                try {
                    PhoneIdentity identity = PhoneIdentity.load();
                    if (destroyed) return;
                    store = new PhoneServerStore(this);
                    // Open and validate the database before announcing readiness.
                    store.getWritableDatabase();
                    server = new PhoneServer(store, identity, InetAddress.getByName("0.0.0.0"), 8443);
                    if (destroyed) return;
                    wake = getSystemService(PowerManager.class).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Pulse:PhoneServer");
                    wake.acquire();
                    server.start(); host.running(this, identity.fingerprint, server.port());
                } catch (Exception error) { host.failed(this); }
            });
        } catch (RuntimeException error) { host.failed(this); }
    }
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && STOP.equals(intent.getAction())) stopSelf();
        return START_NOT_STICKY;
    }
    @Override public void onDestroy() {
        destroyed = true; host.stopping(this);
        worker.execute(() -> {
            try {
                if (server != null) server.close();
                if (store != null) store.close();
            } finally {
                if (wake != null && wake.isHeld()) wake.release();
                host.stopped(this);
            }
        });
        worker.shutdown(); stopForeground(STOP_FOREGROUND_REMOVE); super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
