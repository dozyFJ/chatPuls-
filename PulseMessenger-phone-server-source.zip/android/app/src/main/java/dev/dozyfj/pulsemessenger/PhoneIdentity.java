package dev.dozyfj.pulsemessenger;

import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import java.math.BigInteger;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Date;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.security.auth.x500.X500Principal;

final class PhoneIdentity {
    final SSLContext tls;
    final String fingerprint;
    PhoneIdentity(KeyStore keys, char[] password, String alias) throws Exception {
        KeyManagerFactory factory = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        factory.init(keys, password);
        tls = SSLContext.getInstance("TLS"); tls.init(factory.getKeyManagers(), null, new SecureRandom());
        fingerprint = PhoneServerStore.hex(MessageDigest.getInstance("SHA-256").digest(keys.getCertificate(alias).getEncoded()));
    }
    static PhoneIdentity load() throws Exception {
        String alias = "pulse-phone-host";
        KeyStore keys = KeyStore.getInstance("AndroidKeyStore"); keys.load(null);
        if (!keys.containsAlias(alias)) {
            KeyPairGenerator generator = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_RSA, "AndroidKeyStore");
            generator.initialize(new KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_SIGN | KeyProperties.PURPOSE_VERIFY)
                    .setKeySize(2048).setDigests(KeyProperties.DIGEST_SHA256, KeyProperties.DIGEST_SHA512)
                    .setSignaturePaddings(KeyProperties.SIGNATURE_PADDING_RSA_PKCS1)
                    .setCertificateSubject(new X500Principal("CN=Pulse phone server"))
                    .setCertificateSerialNumber(BigInteger.ONE)
                    .setCertificateNotBefore(new Date(0)).setCertificateNotAfter(new Date(4_102_444_800_000L)).build());
            generator.generateKeyPair();
        }
        return new PhoneIdentity(keys, null, alias);
    }
}
