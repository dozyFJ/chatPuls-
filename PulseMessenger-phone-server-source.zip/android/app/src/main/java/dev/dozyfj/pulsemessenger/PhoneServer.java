package dev.dozyfj.pulsemessenger;

import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLSocket;

/** A small bounded HTTP/1.1 API over TLS; no WebView or Node installation is needed. */
final class PhoneServer implements AutoCloseable {
    private final PhoneServerStore store;
    private final SSLServerSocket listener;
    private final ThreadPoolExecutor workers = new ThreadPoolExecutor(4, 4, 0, TimeUnit.SECONDS, new ArrayBlockingQueue<>(16));
    private final Set<Socket> sockets = ConcurrentHashMap.newKeySet();
    private final Map<String, long[]> attempts = new HashMap<>();
    private Thread acceptor;
    PhoneServer(PhoneServerStore store, PhoneIdentity identity, InetAddress bind, int port) throws IOException {
        this.store = store;
        listener = (SSLServerSocket) identity.tls.getServerSocketFactory().createServerSocket(port, 16, bind);
        listener.setEnabledProtocols(new String[]{"TLSv1.2"});
    }
    int port() { return listener.getLocalPort(); }
    void start() {
        acceptor = new Thread(() -> {
            while (!listener.isClosed()) {
                try {
                    SSLSocket socket = (SSLSocket) listener.accept();
                    sockets.add(socket); socket.setSoTimeout(8000);
                    try { workers.execute(() -> serve(socket)); }
                    catch (java.util.concurrent.RejectedExecutionException error) { sockets.remove(socket); socket.close(); }
                } catch (IOException error) {
                    if (!listener.isClosed()) close();
                }
            }
        }, "pulse-phone-listener");
        acceptor.start();
    }
    private synchronized boolean allowed(String address) {
        long now = System.currentTimeMillis();
        attempts.entrySet().removeIf(entry -> now - entry.getValue()[0] >= 60_000);
        long[] entry = attempts.get(address);
        if (entry == null) {
            if (attempts.size() >= 1024) return false;
            attempts.put(address, new long[]{now, 1}); return true;
        }
        return ++entry[1] <= 30;
    }
    private static String line(InputStream input, int[] remaining) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int b;
        while ((b = input.read()) != -1) {
            if (--remaining[0] < 0) throw new PhoneServerStore.Failure(431);
            if (b == '\n') {
                byte[] bytes = out.toByteArray();
                if (bytes.length == 0 || bytes[bytes.length - 1] != '\r') throw new PhoneServerStore.Failure(400);
                return new String(bytes, 0, bytes.length - 1, StandardCharsets.US_ASCII);
            }
            out.write(b);
        }
        throw new IOException("Incomplete request");
    }
    private void serve(SSLSocket socket) {
        try (socket) {
            try {
                socket.startHandshake();
                InputStream input = socket.getInputStream(); int[] remaining = {8192};
                String[] request = line(input, remaining).split(" ", -1);
                if (request.length != 3 || !request[2].equals("HTTP/1.1") || !request[1].startsWith("/")) throw new PhoneServerStore.Failure(400);
                Map<String, String> headers = new HashMap<>();
                String header;
                while (!(header = line(input, remaining)).isEmpty()) {
                    int colon = header.indexOf(':'); if (colon < 1) throw new PhoneServerStore.Failure(400);
                    String name = header.substring(0, colon).toLowerCase(java.util.Locale.ROOT);
                    if (!name.matches("[a-z0-9-]+") || headers.put(name, header.substring(colon + 1).trim()) != null) throw new PhoneServerStore.Failure(400);
                }
                if (headers.containsKey("transfer-encoding")) throw new PhoneServerStore.Failure(400);
                String lengthText = headers.getOrDefault("content-length", "0");
                if (!lengthText.matches("[0-9]{1,6}")) throw new PhoneServerStore.Failure(400);
                int length = Integer.parseInt(lengthText); if (length > 16_384) throw new PhoneServerStore.Failure(413);
                URI uri;
                try { uri = new URI(request[1]); } catch (Exception error) { throw new PhoneServerStore.Failure(400); }
                if (uri.getHost() != null || uri.getFragment() != null) throw new PhoneServerStore.Failure(400);
                String path = uri.getPath();
                boolean auth = request[0].equals("POST") && (path.equals("/v1/register") || path.equals("/v1/login"));
                if (auth && !allowed(socket.getInetAddress().getHostAddress())) throw new PhoneServerStore.Failure(429);
                String user = null;
                if (!(request[0].equals("GET") && path.equals("/health")) && !auth) user = store.user(headers.get("authorization"));
                JSONObject payload = null;
                if (request[0].equals("POST")) {
                    byte[] bytes = new byte[length]; int read = 0, n;
                    while (read < length && (n = input.read(bytes, read, length - read)) != -1) read += n;
                    if (read != length) throw new PhoneServerStore.Failure(400);
                    try { payload = new JSONObject(new String(bytes, StandardCharsets.UTF_8)); }
                    catch (Exception error) { throw new PhoneServerStore.Failure(400); }
                }
                JSONObject result;
                if (request[0].equals("GET") && path.equals("/health")) result = new JSONObject().put("ok", true);
                else if (auth) result = store.authenticate(payload, path.equals("/v1/register"));
                else if (request[0].equals("POST") && path.equals("/v1/messages")) result = store.send(user, payload);
                else if (request[0].equals("GET") && path.equals("/v1/messages")) {
                    String query = uri.getRawQuery();
                    if (query != null && !query.matches("after=[0-9]{1,15}")) throw new PhoneServerStore.Failure(400);
                    result = store.fetch(user, query == null ? "0" : query.substring(6));
                } else throw new PhoneServerStore.Failure(404);
                reply(socket, 200, result.toString());
            } catch (PhoneServerStore.Failure failure) { reply(socket, failure.status, "{\"error\":\"request rejected\"}"); }
            catch (Exception error) { if (!socket.isClosed()) reply(socket, 500, "{\"error\":\"server error\"}"); }
        } catch (IOException ignored) { }
        finally { sockets.remove(socket); }
    }
    private static void reply(Socket socket, int status, String json) throws IOException {
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        String headers = "HTTP/1.1 " + status + " Result\r\nContent-Type: application/json; charset=utf-8\r\nContent-Length: " + bytes.length
                + "\r\nCache-Control: no-store\r\nX-Content-Type-Options: nosniff\r\nConnection: close\r\n\r\n";
        OutputStream output = socket.getOutputStream(); output.write(headers.getBytes(StandardCharsets.US_ASCII)); output.write(bytes); output.flush();
    }
    @Override public void close() {
        try { listener.close(); } catch (IOException ignored) { }
        for (Socket socket : sockets) try { socket.close(); } catch (IOException ignored) { }
        workers.shutdownNow();
        try { workers.awaitTermination(10, TimeUnit.SECONDS); }
        catch (InterruptedException error) { Thread.currentThread().interrupt(); }
    }
}
