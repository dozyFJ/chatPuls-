package dev.dozyfj.pulsemessenger;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Build;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.regex.Pattern;
import javax.net.ssl.HttpsURLConnection;

final class UpdateClient implements UpdateManager.Source {
    static final String FEED = "https://raw.githubusercontent.com/dozyFJ/chatPuls-/updates/";
    private static final Pattern APK_URL = Pattern.compile(Pattern.quote(FEED) + "releases/PulseMessenger-[0-9]+(?:\\.[0-9]+)*\\.apk");
    private static final Pattern HASH = Pattern.compile("[0-9a-f]{64}");
    private static final int MANIFEST_LIMIT = 16 * 1024;
    private static final int APK_LIMIT = 100 * 1024 * 1024;
    record Update(long code, String name, String url, String hash) {}
    private final Context context;
    private final PackageManager packages;

    UpdateClient(Context context) { this.context = context.getApplicationContext(); packages = context.getPackageManager(); }
    private PackageInfo installed() throws PackageManager.NameNotFoundException {
        return packages.getPackageInfo(context.getPackageName(), signingFlag());
    }
    static Update parseManifest(String data, long currentCode) throws Exception {
        JSONObject json = new JSONObject(data);
        long code = json.getLong("versionCode");
        String name = json.getString("versionName");
        String url = json.getString("url");
        String hash = json.getString("sha256").toLowerCase(Locale.ROOT);
        if (code <= 0 || code > Integer.MAX_VALUE || name.trim().isEmpty() || name.length() > 80
                || !APK_URL.matcher(url).matches() || !HASH.matcher(hash).matches()) throw new IOException("Invalid update manifest");
        return code > currentCode ? new Update(code, name, url, hash) : null;
    }
    @Override public Update check() throws Exception {
        HttpsURLConnection connection = connect(FEED + "latest.json");
        try (InputStream input = connection.getInputStream(); ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
            transfer(input, buffer, null, MANIFEST_LIMIT);
            return parseManifest(new String(buffer.toByteArray(), StandardCharsets.UTF_8), versionCode(installed()));
        } finally { connection.disconnect(); }
    }
    @Override public File download(Update update) throws Exception {
        File dir = new File(context.getCacheDir(), "updates");
        if (!dir.isDirectory() && !dir.mkdirs()) throw new IOException("Cannot create update cache");
        File partial = File.createTempFile("download-", ".apk", dir);
        File destination = new File(dir, "PulseMessenger-" + update.code() + ".apk");
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            HttpsURLConnection connection = connect(update.url());
            try (InputStream input = connection.getInputStream(); FileOutputStream output = new FileOutputStream(partial)) {
                transfer(input, output, digest, APK_LIMIT);
            } finally { connection.disconnect(); }
            if (!update.hash().equals(hex(digest.digest()))) throw new IOException("Update checksum mismatch");
            verifyPackage(partial, update);
            if (!partial.renameTo(destination)) throw new IOException("Cannot save update");
            return destination;
        } finally { partial.delete(); }
    }
    @Override public void verifyReady(File file, Update update) throws Exception {
        File dir = new File(context.getCacheDir(), "updates").getCanonicalFile();
        if (!dir.equals(file.getCanonicalFile().getParentFile()) || !file.isFile()) throw new IOException("Invalid update file");
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (InputStream input = new FileInputStream(file)) {
            transfer(input, new OutputStream() {
                @Override public void write(int b) { }
                @Override public void write(byte[] data, int offset, int length) { }
            }, digest, APK_LIMIT);
        }
        if (!update.hash().equals(hex(digest.digest()))) throw new IOException("Update checksum mismatch");
        verifyPackage(file, update);
    }
    private void verifyPackage(File file, Update update) throws Exception {
        PackageInfo archive = packages.getPackageArchiveInfo(file.getPath(), signingFlag());
        if (!validPackage(archive, installed(), context.getPackageName(), update.code())) throw new IOException("Update package, version or signature mismatch");
    }
    static boolean validPackage(PackageInfo archive, PackageInfo installed, String packageName, long expectedCode) {
        if (archive == null || installed == null || !packageName.equals(archive.packageName)
                || versionCode(archive) != expectedCode || expectedCode <= versionCode(installed)) return false;
        Signature[] left = signers(archive), right = signers(installed);
        return left != null && right != null && left.length > 0
                && new HashSet<>(Arrays.asList(left)).equals(new HashSet<>(Arrays.asList(right)));
    }
    private static void transfer(InputStream input, OutputStream output, MessageDigest digest, int limit) throws IOException {
        byte[] data = new byte[16384]; int total = 0, n;
        while ((n = input.read(data)) != -1) {
            if (Thread.currentThread().isInterrupted()) throw new IOException("Interrupted");
            total += n; if (total > limit) throw new IOException("Update too large");
            if (digest != null) digest.update(data, 0, n); output.write(data, 0, n);
        }
    }
    private static String hex(byte[] bytes) {
        StringBuilder out = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) out.append(String.format(Locale.ROOT, "%02x", b & 0xff));
        return out.toString();
    }
    private static HttpsURLConnection connect(String url) throws IOException {
        HttpsURLConnection connection = (HttpsURLConnection) new URL(url).openConnection();
        connection.setInstanceFollowRedirects(false); connection.setConnectTimeout(10000); connection.setReadTimeout(15000);
        try { if (connection.getResponseCode() != 200) throw new IOException("Update server unavailable"); return connection; }
        catch (IOException e) { connection.disconnect(); throw e; }
    }
    @SuppressWarnings("deprecation") private static int signingFlag() { return Build.VERSION.SDK_INT >= 28 ? PackageManager.GET_SIGNING_CERTIFICATES : PackageManager.GET_SIGNATURES; }
    @SuppressWarnings("deprecation") private static long versionCode(PackageInfo info) { return Build.VERSION.SDK_INT >= 28 ? info.getLongVersionCode() : info.versionCode; }
    @SuppressWarnings("deprecation") private static Signature[] signers(PackageInfo info) { return Build.VERSION.SDK_INT >= 28 ? (info.signingInfo == null ? null : info.signingInfo.getApkContentsSigners()) : info.signatures; }
}
