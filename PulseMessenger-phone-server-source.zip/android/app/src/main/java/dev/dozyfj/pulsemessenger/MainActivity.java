package dev.dozyfj.pulsemessenger;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import org.json.JSONObject;
import java.io.File;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public final class MainActivity extends Activity {
    private static final int CHATS = 0, CONTACTS = 1, SETTINGS = 2, FEED = 3;
    private static final int INSTALL_PERMISSION = 41;
    private SharedPreferences preferences;
    private ChatStore store;
    private boolean dark;
    private int page = CHATS;
    private int chatFilter = ChatStore.ALL;
    private int feedTab;
    private static final String[] FEED_TABS = {"Стена", "Новости", "Сообщества"};
    private String peer;
    private String connectionStatus = "";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final AtomicBoolean syncing = new AtomicBoolean();
    private LinearLayout content, list, compose, dock;
    private LinearLayout chatTabs;
    private HorizontalScrollView tabScroller;
    private Button newChatButton;
    private ScrollView scroll;
    private TextView status;
    private TextView headerTitle, headerAction, headerBack;
    private EditText messageInput;
    private TextView updateText;
    private Button updateButton;
    private UpdateManager updates;
    private PhoneHost phoneHost;
    private TextView hostText;
    private Button hostButton, useHostButton, shareHostButton;
    private EditText serverField;
    private final Runnable hostListener = this::refreshHostControls;
    private boolean awaitingInstallPermission;
    private final UpdateManager.Listener updateListener = this::onUpdateChanged;
    private final Runnable poll = new Runnable() {
        @Override public void run() { sync(); refreshHostControls(); handler.postDelayed(this, 6000); }
    };

    @Override protected void onCreate(Bundle state) {
        preferences = getSharedPreferences("pulse", MODE_PRIVATE);
        dark = preferences.getBoolean("dark", false);
        if (dark) setTheme(R.style.PulseDarkTheme);
        super.onCreate(state);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        store = new ChatStore(this);
        updates = UpdateManager.get(this);
        phoneHost = PhoneHost.get(this);
        if (state != null) {
            page = state.getInt("page", CHATS);
            chatFilter = state.getInt("chatFilter", ChatStore.ALL);
            feedTab = state.getInt("feedTab", 0);
            if (feedTab < 0 || feedTab >= FEED_TABS.length) feedTab = 0;
            peer = state.getString("peer");
            awaitingInstallPermission = state.getBoolean("awaitingInstallPermission", false);
            if (page < CHATS || page > FEED) page = CHATS;
            if (chatFilter < ChatStore.ALL || chatFilter > ChatStore.ARCHIVED) chatFilter = ChatStore.ALL;
        }
        buildShell();
        render();
    }
    @Override protected void onResume() { super.onResume(); handler.post(poll); updates.bind(updateListener); phoneHost.bind(hostListener); updates.checkIfNeeded(); }
    @Override protected void onPause() { handler.removeCallbacks(poll); updates.unbind(updateListener); phoneHost.unbind(hostListener); super.onPause(); }
    @Override protected void onDestroy() { handler.removeCallbacksAndMessages(null); worker.shutdown(); super.onDestroy(); }
    @Override protected void onSaveInstanceState(Bundle state) {
        state.putInt("page", page); state.putInt("feedTab", feedTab); state.putInt("chatFilter", chatFilter); state.putString("peer", peer); state.putBoolean("awaitingInstallPermission", awaitingInstallPermission); super.onSaveInstanceState(state);
    }
    @Override public void onBackPressed() {
        if (peer != null) { peer = null; page = CHATS; render(); }
        else if (page != CHATS) { page = CHATS; render(); }
        else super.onBackPressed();
    }

    private boolean onlineAccount() { return !preferences.getString("token", "").isEmpty(); }
    private String user() { return onlineAccount() ? preferences.getString("user", "") : "я"; }
    private String owner() { return onlineAccount() ? preferences.getString("server", "") + "|" + user() : "local"; }
    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    private int ink() { return dark ? 0xFFF4F4F4 : 0xFF242424; }
    private int muted() { return dark ? 0xFFCCCCCC : 0xFF5C5C5C; }
    private GradientDrawable glass(int top, int bottom, int radius) {
        GradientDrawable shape = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{top, bottom});
        shape.setCornerRadius(dp(radius)); shape.setStroke(dp(1), dark ? 0x44FFFFFF : 0x99FFFFFF); return shape;
    }
    private GradientDrawable card() { return glass(dark ? 0xF0323232 : 0xF5FFFFFF, dark ? 0xF0202020 : 0xE8EFEFEF, 22); }
    private LinearLayout column() { LinearLayout view = new LinearLayout(this); view.setOrientation(LinearLayout.VERTICAL); return view; }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this); view.setText(value); view.setTextSize(size); view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return view;
    }
    private Button button(String title, boolean primary) {
        Button b = new Button(this); b.setText(title); b.setAllCaps(false); b.setTextSize(15); b.setMinHeight(dp(48));
        b.setTextColor(primary ? (dark ? 0xFF1B1B1B : Color.WHITE) : ink());
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(dark ? 0x33FFFFFF : 0x26303030),
                primary ? glass(dark ? 0xFFF4F4F4 : 0xFF393939, dark ? 0xFFDEDEDE : 0xFF202020, 16) : card(), null));
        return b;
    }
    private void buildShell() {
        LinearLayout root = column();
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, dark
                ? new int[]{0xFF151515, 0xFF222222, 0xFF101010}
                : new int[]{0xFFF9F9F9, 0xFFF1F1F1, 0xFFE4E4E4}));
        setContentView(root);
        LinearLayout header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL); header.setPadding(dp(14), dp(12), dp(14), dp(12));
        header.setBackground(glass(dark ? 0xFF3A3A3A : 0xFF393939, dark ? 0xFF242424 : 0xFF202020, 0));
        LinearLayout.LayoutParams headerParams = new LinearLayout.LayoutParams(-1, -2);
        root.addView(header, headerParams);
        headerBack = headerControl("‹"); header.addView(headerBack, new LinearLayout.LayoutParams(dp(40), dp(40)));
        LinearLayout heading = column(); LinearLayout.LayoutParams headingParams = new LinearLayout.LayoutParams(0, -2, 1f); headingParams.setMargins(dp(6), 0, dp(6), 0); header.addView(heading, headingParams);
        headerTitle = text("", 20, Color.WHITE, true); heading.addView(headerTitle);
        status = text("", 12, 0xFFD6D6D6, false); heading.addView(status);
        headerAction = headerControl("+"); header.addView(headerAction, new LinearLayout.LayoutParams(dp(40), dp(40)));
        tabScroller = new HorizontalScrollView(this); tabScroller.setHorizontalScrollBarEnabled(false);
        chatTabs = new LinearLayout(this); chatTabs.setPadding(dp(12), dp(3), dp(12), dp(3)); tabScroller.addView(chatTabs);
        root.addView(tabScroller, new LinearLayout.LayoutParams(-1, -2));
        FrameLayout body = new FrameLayout(this); root.addView(body, new LinearLayout.LayoutParams(-1, 0, 1f));
        scroll = new ScrollView(this); scroll.setFillViewport(true);
        body.addView(scroll, new FrameLayout.LayoutParams(-1, -1));
        content = column(); content.setPadding(dp(16), dp(12), dp(16), dp(12)); scroll.addView(content);
        newChatButton = new Button(this); newChatButton.setText("+"); newChatButton.setTextSize(27); newChatButton.setAllCaps(false);
        newChatButton.setContentDescription("Новый чат"); newChatButton.setMinWidth(0); newChatButton.setMinimumWidth(0);
        newChatButton.setPadding(0, 0, 0, 0); newChatButton.setTextColor(dark ? 0xFF202020 : Color.WHITE);
        GradientDrawable fab = new GradientDrawable(); fab.setShape(GradientDrawable.OVAL); fab.setColor(dark ? 0xFFF0F0F0 : 0xFF303030);
        newChatButton.setBackground(new RippleDrawable(ColorStateList.valueOf(dark ? 0x33303030 : 0x33FFFFFF), fab, null));
        newChatButton.setElevation(dp(6)); newChatButton.setOnClickListener(v -> newChat());
        FrameLayout.LayoutParams fabParams = new FrameLayout.LayoutParams(dp(56), dp(56), Gravity.END | Gravity.BOTTOM); fabParams.setMargins(0, 0, dp(18), dp(18)); body.addView(newChatButton, fabParams);
        compose = column(); root.addView(compose, new LinearLayout.LayoutParams(-1, -2));
        dock = new LinearLayout(this); dock.setGravity(Gravity.CENTER_VERTICAL); dock.setPadding(dp(4), dp(5), dp(4), dp(5));
        GradientDrawable dockBackground = glass(dark ? 0xFF333333 : 0xFFFFFFFF, dark ? 0xFF202020 : 0xFFF0F0F0, 0);
        float radius = dp(22);
        dockBackground.setCornerRadii(new float[]{radius, radius, radius, radius, 0, 0, 0, 0});
        dock.setBackground(dockBackground);
        root.addView(dock, new LinearLayout.LayoutParams(-1, -2));
    }
    private void addDock(String symbol, String label, boolean selected, Runnable click) {
        LinearLayout item = column(); item.setGravity(Gravity.CENTER); item.setPadding(dp(2), dp(7), dp(2), dp(7)); item.setMinimumHeight(dp(66));
        item.setClickable(true); item.setFocusable(true); item.setContentDescription(label); item.setSelected(selected);
        int iconColor = selected ? (dark ? 0xFF1B1B1B : Color.WHITE) : ink();
        int circleColor = selected ? (dark ? 0xFFE8E8E8 : 0xFF303030) : (dark ? 0xFF484848 : 0xFFE2E2E2);
        GradientDrawable circle = new GradientDrawable(); circle.setShape(GradientDrawable.OVAL); circle.setColor(circleColor);
        TextView icon = text(symbol, 21, iconColor, true); icon.setGravity(Gravity.CENTER); icon.setBackground(circle); icon.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        TextView name = text(label, 11, selected ? ink() : muted(), selected); name.setGravity(Gravity.CENTER); name.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        item.addView(icon, new LinearLayout.LayoutParams(dp(36), dp(36))); item.addView(name); item.setOnClickListener(v -> click.run()); dock.addView(item, new LinearLayout.LayoutParams(0, -2, 1f));
    }
    private void render() {
        content.removeAllViews(); compose.removeAllViews(); dock.removeAllViews(); list = null; messageInput = null; updateText = null; updateButton = null; hostText = null; hostButton = null; useHostButton = null; shareHostButton = null; serverField = null;
        updateStatus(); updateHeader();
        renderChatTabs();
        boolean showFab = peer == null && page == CHATS;
        newChatButton.setVisibility(showFab ? View.VISIBLE : View.GONE);
        content.setPadding(dp(16), dp(12), dp(16), dp(showFab ? 86 : 12));
        addDock("◉", "Чаты", page == CHATS, () -> { page = CHATS; peer = null; render(); });
        addDock("⚙", "Настройки", page == SETTINGS, () -> { page = SETTINGS; peer = null; render(); });
        addDock("♙", "Контакты", page == CONTACTS, () -> { page = CONTACTS; peer = null; render(); });
        addDock("▤", "Лента", page == FEED, () -> { page = FEED; peer = null; render(); });
        if (peer != null) showConversation();
        else if (page == SETTINGS) showSettings();
        else if (page == FEED) showFeed();
        else showChats();
        scroll.scrollTo(0, 0);
        content.animate().cancel();
        content.setAlpha(0f); content.setTranslationY(dp(6));
        content.animate().alpha(1f).translationY(0f).setDuration(140).start();
    }
    private LinearLayout newCard() {
        LinearLayout card = column(); card.setPadding(dp(16), dp(16), dp(16), dp(16)); card.setBackground(card());
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2); params.bottomMargin = dp(12); content.addView(card, params); return card;
    }
    private void renderChatTabs() {
        chatTabs.removeAllViews();
        boolean feed = page == FEED;
        boolean visible = (page == CHATS || feed) && peer == null;
        tabScroller.setVisibility(visible ? View.VISIBLE : View.GONE);
        if (!visible) return;
        String[] labels = feed ? FEED_TABS : new String[]{"Все", "Входящие", "Архивные"};
        for (int i = 0; i < labels.length; i++) {
            final int filter = i;
            boolean selected = (feed ? feedTab : chatFilter) == i;
            TextView tab = text(labels[i], 14, selected ? (dark ? 0xFF1B1B1B : Color.WHITE) : ink(), selected);
            tab.setGravity(Gravity.CENTER); tab.setPadding(dp(16), dp(10), dp(16), dp(10));
            tab.setMinHeight(dp(44)); tab.setClickable(true); tab.setFocusable(true); tab.setSelected(selected);
            if (selected) tab.setBackground(glass(dark ? 0xFFF4F4F4 : 0xFF393939, dark ? 0xFFDEDEDE : 0xFF202020, 18));
            tab.setOnClickListener(v -> { if (feed) feedTab = filter; else chatFilter = filter; render(); });
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, -2); params.rightMargin = dp(6); chatTabs.addView(tab, params);
        }
    }
    private void showFeed() {
        LinearLayout card = newCard(); card.addView(text(FEED_TABS[feedTab], 20, ink(), true));
        TextView note = text("Лента пока не подключена.", 15, muted(), false); note.setPadding(0, dp(12), 0, 0); card.addView(note);
    }
    private void showChats() {
        LinearLayout card = newCard();
        card.addView(text(page == CONTACTS ? "Контакты" : "Чаты", 20, ink(), true));
        list = column(); card.addView(list); refreshChats();
    }
    private void refreshChats() {
        if (list == null || peer != null || page == SETTINGS) return;
        list.removeAllViews();
        List<String> names = page == CHATS ? store.chats(owner(), user(), chatFilter) : store.chats(owner());
        if (names.isEmpty()) {
            String message = page == CHATS && chatFilter == ChatStore.INCOMING ? "Входящих сообщений пока нет."
                    : page == CHATS && chatFilter == ChatStore.ARCHIVED ? "В архиве пока нет чатов."
                    : "Пока здесь пусто. Нажмите «Новый чат».";
            TextView empty = text(message, 15, muted(), false);
            empty.setPadding(0, dp(14), 0, dp(8)); list.addView(empty); return;
        }
        for (String name : names) {
            LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
            Button entry = button(name, false); entry.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
            entry.setOnClickListener(v -> { peer = name; page = CHATS; render(); });
            row.addView(entry, new LinearLayout.LayoutParams(0, -2, 1f));
            Button actions = button("⋯", false); actions.setContentDescription("Действия чата " + name);
            actions.setOnClickListener(v -> chatActions(name));
            LinearLayout.LayoutParams actionParams = new LinearLayout.LayoutParams(dp(48), dp(48)); actionParams.leftMargin = dp(6); row.addView(actions, actionParams);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.topMargin = dp(8); list.addView(row, p);
        }
    }
    private void newChat() {
        EditText input = new EditText(this); input.setSingleLine(true); input.setHint("Имя пользователя (латиница, цифры, _)");
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        input.setFilters(new InputFilter[]{new InputFilter.LengthFilter(32)});
        LinearLayout wrapper = column(); wrapper.setPadding(dp(20), 0, dp(20), 0); wrapper.addView(input);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Новый чат").setView(wrapper)
                .setNegativeButton("Отмена", null).setPositiveButton("Открыть", null).create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String name = input.getText().toString().trim().toLowerCase(Locale.ROOT);
            if (!name.matches("[a-z0-9_]{3,32}") || name.equals(user())) { input.setError("Введите другое имя: 3–32 символа"); return; }
            store.createChat(owner(), name); store.setArchived(owner(), name, false); peer = name; page = CHATS; dialog.dismiss(); render();
        }));
        showDialog(dialog);
    }
    private void chatActions(String name) {
        String currentOwner = owner(); boolean archived = store.isArchived(currentOwner, name);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle(name)
                .setItems(new String[]{archived ? "Вернуть из архива" : "В архив"}, (ignored, which) -> {
                    store.setArchived(currentOwner, name, !archived); refreshChats();
                }).setNegativeButton("Отмена", null).create();
        showDialog(dialog);
    }
    private void showConversation() {
        LinearLayout card = newCard();
        list = column(); card.addView(list); refreshMessages();
        LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(12), dp(4), dp(12), dp(4));
        compose.addView(row);
        messageInput = new EditText(this); messageInput.setHint("Сообщение"); messageInput.setMinHeight(dp(48));
        messageInput.setMaxLines(4); messageInput.setFilters(new InputFilter[]{new InputFilter.LengthFilter(2000)});
        String draftKey = "draft|" + owner() + "|" + peer;
        messageInput.setText(preferences.getString(draftKey, ""));
        messageInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { preferences.edit().putString(draftKey, s.toString()).apply(); }
            @Override public void afterTextChanged(Editable e) {}
        });
        row.addView(messageInput, new LinearLayout.LayoutParams(0, -2, 1f));
        Button send = button("➤", true); send.setContentDescription("Отправить сообщение");
        row.addView(send, new LinearLayout.LayoutParams(dp(56), dp(48)));
        send.setOnClickListener(v -> {
            String value = messageInput.getText().toString().trim();
            if (value.isEmpty()) return;
            store.queue(owner(), user(), peer, value, !onlineAccount());
            messageInput.setText(""); refreshMessages(); scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN)); sync();
        });
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }
    private void refreshMessages() {
        if (list == null || peer == null) return;
        list.removeAllViews();
        List<ChatStore.Message> messages = store.messages(owner(), user(), peer);
        if (messages.isEmpty()) { TextView empty = text("Сообщений пока нет", 14, muted(), false); empty.setPadding(0, dp(16), 0, dp(8)); list.addView(empty); }
        for (ChatStore.Message message : messages) {
            boolean mine = message.from().equals(user());
            LinearLayout bubble = column(); bubble.setPadding(dp(12), dp(9), dp(12), dp(9)); bubble.setBackground(card());
            bubble.addView(text(message.text(), 16, ink(), false));
            String suffix = message.status() == 1 ? "В очереди" : message.status() == 2 ? "Не отправлено · нажмите для действий" : message.status() == 3 ? "Только на устройстве" : "";
            if (!suffix.isEmpty()) { TextView state = text(suffix, 11, muted(), false); state.setPadding(0, dp(4), 0, 0); bubble.addView(state); }
            if (mine && message.status() == 2) {
                bubble.setClickable(true); bubble.setFocusable(true);
                bubble.setOnClickListener(v -> messageActions(message));
            }
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.topMargin = dp(8); if (mine) p.leftMargin = dp(24); else p.rightMargin = dp(24); list.addView(bubble, p);
        }
    }
    private void messageActions(ChatStore.Message message) {
        String currentOwner = owner();
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Сообщение")
                .setItems(new String[]{"Повторить", "Удалить"}, (ignored, which) -> {
                    if (which == 0) { store.retry(currentOwner, message); sync(); }
                    else store.removeUnsent(currentOwner, message);
                    refreshMessages();
                }).setNegativeButton("Отмена", null).create();
        showDialog(dialog);
    }
    private void showSettings() {
        LinearLayout card = newCard(); card.addView(text("Настройки", 20, ink(), true));
        Switch theme = new Switch(this); theme.setText("Тёмная тема"); theme.setTextColor(ink()); theme.setPadding(0, dp(12), 0, dp(12)); theme.setChecked(dark);
        card.addView(theme); theme.setOnCheckedChangeListener((v, checked) -> { preferences.edit().putBoolean("dark", checked).apply(); recreate(); });
        updateText = text("", 14, muted(), false); updateText.setPadding(0, dp(8), 0, dp(8)); card.addView(updateText);
        updateButton = button("Проверить обновления", false); card.addView(updateButton, new LinearLayout.LayoutParams(-1, -2));
        updateButton.setOnClickListener(v -> { if (updates.phase() == UpdateManager.Phase.READY) requestInstall(); else updates.check(); });
        refreshUpdateControls();
        showPhoneHost();
        if (onlineAccount()) {
            card.addView(text("Аккаунт: " + user(), 16, ink(), true));
            TextView host = text(preferences.getString("server", ""), 13, muted(), false); host.setPadding(0, dp(6), 0, dp(10)); card.addView(host);
            Button local = button("Перейти в локальный режим", false); card.addView(local);
            local.setOnClickListener(v -> {
                preferences.edit().remove("token").remove("user").remove("server").apply();
                connectionStatus = ""; peer = null; render();
            });
            return;
        }
        TextView hint = text("Локальные чаты доступны без сервера. Для переписки укажите интернет-сервер или ссылку с телефона в той же сети Wi-Fi. Затем войдите или создайте аккаунт.", 14, muted(), false);
        hint.setPadding(0, dp(4), 0, dp(8)); card.addView(hint);
        EditText server = field("Адрес сервера или ссылка подключения", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        serverField = server; server.setText(preferences.getString("serverDraft", "")); card.addView(server);
        EditText username = field("Имя пользователя", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS); username.setFilters(new InputFilter[]{new InputFilter.LengthFilter(32)}); card.addView(username);
        EditText password = field("Пароль (минимум 10 символов)", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD); password.setFilters(new InputFilter[]{new InputFilter.LengthFilter(128)}); card.addView(password);
        Button login = button("Войти", true); Button register = button("Создать аккаунт", false);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.topMargin = dp(8); card.addView(login, p);
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(-1, -2); p2.topMargin = dp(8); card.addView(register, p2);
        login.setOnClickListener(v -> authenticate(server, username, password, false, login, register));
        register.setOnClickListener(v -> authenticate(server, username, password, true, login, register));
    }
    private void showPhoneHost() {
        LinearLayout card = newCard(); card.addView(text("Сервер на этом телефоне", 19, ink(), true));
        TextView hint = text("Общий сервер для телефонов в одной сети Wi-Fi. Аккаунты и сообщения сервера хранятся здесь отдельно от локальных чатов.", 14, muted(), false);
        hint.setPadding(0, dp(8), 0, dp(8)); card.addView(hint);
        hostText = text("", 13, muted(), false); hostText.setTextIsSelectable(true); card.addView(hostText);
        hostButton = button("Запустить сервер", false); card.addView(hostButton, new LinearLayout.LayoutParams(-1, -2));
        hostButton.setOnClickListener(v -> { if (phoneHost.phase() == PhoneHost.Phase.RUNNING) phoneHost.stop();
            else {
                if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED)
                    requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 74);
                phoneHost.start();
            } });
        useHostButton = button("Подключиться на этом телефоне", false); card.addView(useHostButton, new LinearLayout.LayoutParams(-1, -2));
        useHostButton.setOnClickListener(v -> {
            String address = phoneHost.localUrl(); if (address.isEmpty()) return;
            preferences.edit().putString("serverDraft", address).apply();
            if (serverField != null) { serverField.setText(address); serverField.requestFocus(); }
            else showDialog(new AlertDialog.Builder(this).setTitle("Подключение к своему серверу")
                    .setMessage("Адрес сохранён. Перейдите в локальный режим, затем создайте аккаунт на сервере телефона или войдите в него.")
                    .setPositiveButton("Понятно", null).create());
        });
        shareHostButton = button("Поделиться подключением", false); card.addView(shareHostButton, new LinearLayout.LayoutParams(-1, -2));
        shareHostButton.setOnClickListener(v -> {
            List<String> addresses = phoneHost.lanUrls(); if (addresses.isEmpty()) return;
            String[] options = addresses.toArray(new String[0]);
            if (options.length == 1) shareHost(options[0]);
            else showDialog(new AlertDialog.Builder(this).setTitle("Выберите адрес своей сети Wi-Fi")
                    .setItems(options, (dialog, which) -> shareHost(options[which])).setNegativeButton("Отмена", null).create());
        });
        refreshHostControls();
    }
    private void shareHost(String address) {
        try { startActivity(Intent.createChooser(new Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_TEXT, address), "Подключение к Pulse")); }
        catch (ActivityNotFoundException error) { Toast.makeText(this, "Скопируйте адрес сервера из настроек", Toast.LENGTH_LONG).show(); }
    }
    private void refreshHostControls() {
        if (hostText == null) return;
        PhoneHost.Phase phase = phoneHost.phase();
        boolean running = phase == PhoneHost.Phase.RUNNING;
        String description;
        if (running) {
            List<String> addresses = phoneHost.lanUrls();
            description = "Сервер включён · HTTPS · порт 8443\n"
                    + (addresses.isEmpty() ? "Подключите Wi-Fi для других телефонов." : String.join("\n\n", addresses))
                    + "\n\nНа другом телефоне вставьте полную ссылку в настройки Pulse. Для интернета нужен отдельный HTTPS-туннель. Сервер расходует заряд; Android может остановить его.";
        } else if (phase == PhoneHost.Phase.STARTING) description = "Запускаем сервер…";
        else if (phase == PhoneHost.Phase.STOPPING) description = "Останавливаем сервер…";
        else if (phase == PhoneHost.Phase.ERROR) description = "Не удалось запустить сервер. Проверьте, свободен ли порт 8443, и повторите.";
        else description = "Сервер выключен. Данные сохраняются после остановки.";
        hostText.setText(description);
        hostButton.setText(running ? "Остановить сервер" : "Запустить сервер");
        hostButton.setEnabled(phase != PhoneHost.Phase.STARTING && phase != PhoneHost.Phase.STOPPING);
        useHostButton.setVisibility(running ? View.VISIBLE : View.GONE);
        shareHostButton.setVisibility(running ? View.VISIBLE : View.GONE);
        shareHostButton.setEnabled(running && !phoneHost.lanUrls().isEmpty());
    }
    private EditText field(String hint, int inputType) { EditText v = new EditText(this); v.setHint(hint); v.setTextColor(ink()); v.setHintTextColor(muted()); v.setSingleLine(true); v.setInputType(inputType); return v; }
    private void showDialog(AlertDialog dialog) {
        if (dialog.getWindow() != null) dialog.getWindow().setWindowAnimations(R.style.PulseDialogAnimation);
        dialog.show();
    }
    private void refreshUpdateControls() {
        if (updateText == null || updateButton == null) return;
        UpdateManager.Phase phase = updates.phase();
        String description;
        switch (phase) {
            case CHECKING: description = "Проверяем обновления…"; break;
            case DOWNLOADING: description = "Скачиваем обновление…"; break;
            case CURRENT: description = "Установлена последняя версия"; break;
            case READY: description = "Версия " + updates.update().name() + " готова к установке"; break;
            case ERROR: description = "Не удалось проверить или скачать обновление"; break;
            default: description = "Обновления";
        }
        updateText.setText(description);
        updateButton.setText(phase == UpdateManager.Phase.READY ? "Установить обновление" : "Проверить обновления");
        updateButton.setEnabled(phase != UpdateManager.Phase.CHECKING && phase != UpdateManager.Phase.DOWNLOADING);
    }
    private void onUpdateChanged() {
        refreshUpdateControls(); updateHeader();
        if (updates.takeOffer()) {
            AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Обновление готово")
                    .setMessage("Версия " + updates.update().name() + " скачана и проверена. Подтвердите установку в Android, затем откройте приложение снова.")
                    .setNegativeButton("Позже", null)
                    .setPositiveButton("Установить", (ignored, which) -> requestInstall()).create();
            showDialog(dialog);
        }
    }
    private void requestInstall() {
        if (!getPackageManager().canRequestPackageInstalls()) {
            try {
                awaitingInstallPermission = true;
                startActivityForResult(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName())), INSTALL_PERMISSION);
            } catch (ActivityNotFoundException | SecurityException error) {
                awaitingInstallPermission = false;
                Toast.makeText(this, "Не удалось открыть настройки установки", Toast.LENGTH_LONG).show();
            }
            return;
        }
        updates.verify(this::openInstaller, () -> { if (!isDestroyed()) Toast.makeText(this, "Не удалось проверить обновление", Toast.LENGTH_LONG).show(); });
    }
    private void openInstaller(File file) {
        if (isDestroyed() || isFinishing()) return;
        try {
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".updates", file);
            startActivity(new Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION));
        } catch (ActivityNotFoundException | SecurityException | IllegalArgumentException error) {
            Toast.makeText(this, "Не удалось открыть установщик", Toast.LENGTH_LONG).show();
        }
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == INSTALL_PERMISSION && awaitingInstallPermission) {
            awaitingInstallPermission = false;
            if (getPackageManager().canRequestPackageInstalls()) requestInstall();
        }
    }
    private void authenticate(EditText server, EditText username, EditText password, boolean register, Button login, Button signup) {
        final String base;
        try { base = PulseApi.normalizeUrl(server.getText().toString()); }
        catch (Exception e) { server.setError("Укажите HTTPS-адрес или полную ссылку подключения"); return; }
        preferences.edit().putString("serverDraft", base).apply();
        String name = username.getText().toString().trim().toLowerCase(Locale.ROOT), secret = password.getText().toString();
        if (!name.matches("[a-z0-9_]{3,32}")) { username.setError("Имя: 3–32 латинских символа, цифры или _"); return; }
        if (secret.length() < 10 || secret.length() > 128) { password.setError("Пароль: от 10 до 128 символов"); return; }
        login.setEnabled(false); signup.setEnabled(false); connectionStatus = "Подключение…"; updateStatus();
        worker.execute(() -> {
            try {
                JSONObject result = new PulseApi(base, null).request(register ? "/v1/register" : "/v1/login", new JSONObject().put("username", name).put("password", secret));
                String returnedUser = result.getString("username"), token = result.getString("token");
                if (!name.equals(returnedUser) || !token.matches("[a-f0-9]{64}")) throw new IllegalStateException("Некорректный ответ");
                handler.post(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    preferences.edit().putString("server", base).putString("user", name).putString("token", token).apply();
                    connectionStatus = "Подключено"; peer = null; page = CHATS; render(); sync();
                });
            } catch (Exception error) {
                handler.post(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    login.setEnabled(true); signup.setEnabled(true);
                    connectionStatus = error instanceof PulseApi.ApiError ? "Не удалось войти: " + ((PulseApi.ApiError) error).code : "Нет соединения с сервером";
                    updateStatus();
                });
            }
        });
    }
    private void updateStatus() {
        status.setText(onlineAccount() ? user() + (connectionStatus.isEmpty() ? " · Ожидание сети" : " · " + connectionStatus) : "Локальный режим");
    }
    private TextView headerControl(String glyph) {
        TextView control = text(glyph, 24, Color.WHITE, true); control.setGravity(Gravity.CENTER);
        GradientDrawable background = new GradientDrawable(); background.setShape(GradientDrawable.OVAL); background.setColor(0x33FFFFFF);
        control.setBackground(background); control.setClickable(true); control.setFocusable(true); return control;
    }
    private void updateHeader() {
        if (headerTitle == null || updates == null) return;
        headerBack.setVisibility(peer == null ? View.GONE : View.VISIBLE);
        if (peer != null) {
            headerTitle.setText(peer); headerBack.setContentDescription("Назад к чатам");
            headerBack.setOnClickListener(v -> { peer = null; page = CHATS; render(); });
            headerAction.setText("↻"); headerAction.setContentDescription("Обновить сообщения");
            headerAction.setEnabled(onlineAccount()); headerAction.setAlpha(onlineAccount() ? 1f : 0.45f);
            headerAction.setOnClickListener(v -> sync());
        } else if (page == SETTINGS) {
            headerTitle.setText("Настройки");
            boolean ready = updates.phase() == UpdateManager.Phase.READY;
            boolean busy = updates.phase() == UpdateManager.Phase.CHECKING || updates.phase() == UpdateManager.Phase.DOWNLOADING;
            headerAction.setText(ready ? "↓" : "↻"); headerAction.setContentDescription(ready ? "Установить обновление" : "Проверить обновления");
            headerAction.setEnabled(!busy); headerAction.setAlpha(busy ? 0.45f : 1f);
            headerAction.setOnClickListener(v -> { if (updates.phase() == UpdateManager.Phase.READY) requestInstall(); else updates.check(); });
        } else if (page == FEED) {
            headerTitle.setText("Лента"); headerAction.setText("⋯"); headerAction.setContentDescription("Разделы ленты");
            headerAction.setEnabled(true); headerAction.setAlpha(1f);
            headerAction.setOnClickListener(v -> showDialog(new AlertDialog.Builder(this).setTitle("Разделы ленты")
                    .setItems(FEED_TABS, (ignored, which) -> { feedTab = which; render(); }).setNegativeButton("Отмена", null).create()));
        } else if (page == CONTACTS) {
            headerTitle.setText("Контакты");
            headerAction.setText("+"); headerAction.setContentDescription("Создать чат");
            headerAction.setEnabled(true); headerAction.setAlpha(1f); headerAction.setOnClickListener(v -> newChat());
        } else {
            headerTitle.setText("Чаты");
            headerAction.setText("⋯"); headerAction.setContentDescription("Разделы чатов");
            headerAction.setEnabled(true); headerAction.setAlpha(1f);
            headerAction.setOnClickListener(v -> showDialog(new AlertDialog.Builder(this).setTitle("Разделы чатов")
                    .setItems(new String[]{"Все", "Входящие", "Архивные"}, (ignored, which) -> { chatFilter = which; render(); })
                    .setNegativeButton("Отмена", null).create()));
        }
    }
    private void sync() {
        if (!onlineAccount() || !syncing.compareAndSet(false, true)) return;
        String currentOwner = owner(), currentUser = user(), token = preferences.getString("token", ""), base = preferences.getString("server", "");
        worker.execute(() -> {
            String result = "Подключено";
            try {
                PulseApi api = new PulseApi(base, token);
                for (ChatStore.Message message : store.pending(currentOwner)) {
                    try { store.delivered(currentOwner, currentUser, api.send(message)); }
                    catch (PulseApi.ApiError e) { if (e.code == 400 || e.code == 404 || e.code == 409) { store.markFailed(currentOwner, message); result = "Есть неотправленные сообщения"; } else throw e; }
                }
                List<ChatStore.Message> incoming;
                do { incoming = api.fetch(store.cursor(currentOwner)); store.received(currentOwner, currentUser, incoming); } while (incoming.size() == 100);
            } catch (PulseApi.ApiError e) { result = e.code == 401 ? "Войдите снова" : "Нет соединения с сервером"; }
            catch (Exception e) { result = "Нет соединения с сервером"; }
            String finalResult = result;
            syncing.set(false);
            handler.post(() -> {
                if (isFinishing() || isDestroyed() || !currentOwner.equals(owner())) return;
                connectionStatus = finalResult; updateStatus(); if (peer != null) refreshMessages(); else refreshChats();
            });
        });
    }
}
