package dev.dozyfj.pulsemessenger;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.security.cert.X509Certificate;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

final class PulseApi {
    static String normalizeUrl(String input) throws Exception {
        URL url = new URL(input.trim());
        String protocol = url.getProtocol().toLowerCase(Locale.ROOT);
        String host = url.getHost().toLowerCase(Locale.ROOT);
        boolean local = host.equals("localhost") || host.equals("127.0.0.1") || host.equals("10.0.2.2");
        if ((!protocol.equals("https") && !(protocol.equals("http") && local)) || host.isEmpty()
                || url.getUserInfo() != null || url.getQuery() != null
                || (url.getRef() != null && (!protocol.equals("https") || !url.getRef().matches("sha256=[a-f0-9]{64}")))
                || !(url.getPath().isEmpty() || url.getPath().equals("/"))) throw new IOException("Укажите HTTPS-адрес сервера без пути");
        int port = url.getPort();
        if (port == 0 || port > 65535 || port < -1 || host.contains(":")) throw new IOException("Некорректный адрес сервера");
        return protocol + "://" + host + (port < 0 ? "" : ":" + port) + (url.getRef() == null ? "" : "#" + url.getRef());
    }
    static final class ApiError extends IOException {
        final int code;
        ApiError(int code) { super("Ошибка сервера: " + code); this.code = code; }
    }
    private final String base;
    private final String token;
    PulseApi(String base, String token) { this.base = base; this.token = token; }
    JSONObject request(String path, JSONObject payload) throws Exception {
        URL endpoint = new URL(base);
        String address = base.split("#", 2)[0];
        HttpURLConnection connection = (HttpURLConnection) new URL(address + path).openConnection();
        if (endpoint.getRef() != null) {
            if (!(connection instanceof HttpsURLConnection) || !endpoint.getRef().matches("sha256=[a-f0-9]{64}")) throw new IOException("Некорректный отпечаток сервера");
            String pin = endpoint.getRef().substring(7);
            SSLContext tls = SSLContext.getInstance("TLS");
            tls.init(null, new TrustManager[]{new X509TrustManager() {
                @Override public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
                @Override public void checkClientTrusted(X509Certificate[] chain, String authType) throws java.security.cert.CertificateException { throw new java.security.cert.CertificateException("Client authentication unsupported"); }
                @Override public void checkServerTrusted(X509Certificate[] chain, String authType) throws java.security.cert.CertificateException {
                    try {
                        if (chain.length == 0 || !pin.equals(PhoneServerStore.hex(MessageDigest.getInstance("SHA-256").digest(chain[0].getEncoded())))) throw new java.security.cert.CertificateException("Server fingerprint differs");
                        chain[0].checkValidity();
                    } catch (java.security.cert.CertificateException error) { throw error; }
                    catch (Exception error) { throw new java.security.cert.CertificateException(error); }
                }
            }}, null);
            HttpsURLConnection https = (HttpsURLConnection) connection;
            https.setSSLSocketFactory(tls.getSocketFactory());
            // A pairing link identifies this exact certificate independently of the phone's changing IP.
            https.setHostnameVerifier((hostname, session) -> {
                try { return pin.equals(PhoneServerStore.hex(MessageDigest.getInstance("SHA-256").digest(session.getPeerCertificates()[0].getEncoded()))); }
                catch (Exception error) { return false; }
            });
        }
        connection.setConnectTimeout(8000); connection.setReadTimeout(10000);
        connection.setInstanceFollowRedirects(false);
        if (token != null) connection.setRequestProperty("Authorization", "Bearer " + token);
        try {
            if (payload != null) {
                byte[] bytes = payload.toString().getBytes(StandardCharsets.UTF_8);
                connection.setRequestMethod("POST"); connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                connection.setFixedLengthStreamingMode(bytes.length);
                try (OutputStream output = connection.getOutputStream()) { output.write(bytes); }
            }
            int status = connection.getResponseCode();
            if (status != 200) throw new ApiError(status);
            try (InputStream input = connection.getInputStream(); ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
                byte[] part = new byte[4096]; int size = 0, n;
                while ((n = input.read(part)) != -1) {
                    size += n; if (size > 512_000) throw new IOException("Ответ сервера слишком большой");
                    buffer.write(part, 0, n);
                }
                return new JSONObject(new String(buffer.toByteArray(), StandardCharsets.UTF_8));
            }
        } finally { connection.disconnect(); }
    }
    static ChatStore.Message parseMessage(JSONObject json) throws Exception {
        return new ChatStore.Message(json.getString("id"), json.getString("from"), json.getString("to"),
                json.getString("text"), json.getLong("time"), json.getLong("sequence"), 0);
    }
    ChatStore.Message send(ChatStore.Message message) throws Exception {
        return parseMessage(request("/v1/messages", new JSONObject().put("id", message.id()).put("to", message.to()).put("text", message.text())));
    }
    List<ChatStore.Message> fetch(long after) throws Exception {
        JSONArray array = request("/v1/messages?after=" + after, null).getJSONArray("messages");
        List<ChatStore.Message> result = new ArrayList<>();
        for (int i = 0; i < array.length(); i++) result.add(parseMessage(array.getJSONObject(i)));
        return result;
    }
}
