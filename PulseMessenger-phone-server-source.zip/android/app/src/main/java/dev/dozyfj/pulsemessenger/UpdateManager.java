package dev.dozyfj.pulsemessenger;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

/** Process-scoped so an activity recreation does not start a second download. */
final class UpdateManager {
    enum Phase { IDLE, CHECKING, DOWNLOADING, CURRENT, READY, ERROR }
    interface Listener { void changed(); }
    interface Source {
        UpdateClient.Update check() throws Exception;
        File download(UpdateClient.Update update) throws Exception;
        void verifyReady(File file, UpdateClient.Update update) throws Exception;
    }
    private static UpdateManager instance;
    static synchronized UpdateManager get(Context context) {
        if (instance == null) instance = new UpdateManager(new UpdateClient(context));
        return instance;
    }
    private final Source client;
    private final ExecutorService executor = Executors.newSingleThreadExecutor(task -> {
        Thread thread = new Thread(task, "pulse-updates"); thread.setDaemon(true); return thread;
    });
    private final Handler main = new Handler(Looper.getMainLooper());
    private Listener listener;
    private Phase phase = Phase.IDLE;
    private UpdateClient.Update update;
    private File apk;
    private boolean offered;
    UpdateManager(Source client) { this.client = client; }
    Phase phase() { return phase; }
    UpdateClient.Update update() { return update; }
    void bind(Listener listener) { this.listener = listener; listener.changed(); }
    void unbind(Listener listener) { if (this.listener == listener) this.listener = null; }
    private void changed() { if (listener != null) listener.changed(); }
    boolean takeOffer() {
        if (phase != Phase.READY || offered) return false;
        offered = true; return true;
    }
    void checkIfNeeded() {
        if (phase == Phase.IDLE || phase == Phase.CURRENT || phase == Phase.ERROR) check();
    }
    void check() {
        if (phase == Phase.CHECKING || phase == Phase.DOWNLOADING) return;
        phase = Phase.CHECKING; changed();
        executor.execute(() -> {
            try {
                UpdateClient.Update next = client.check();
                if (next == null) {
                    main.post(() -> { update = null; apk = null; phase = Phase.CURRENT; changed(); });
                    return;
                }
                main.post(() -> { phase = Phase.DOWNLOADING; changed(); });
                File file = client.download(next);
                main.post(() -> { update = next; apk = file; offered = false; phase = Phase.READY; changed(); });
            } catch (Exception error) {
                main.post(() -> { update = null; apk = null; phase = Phase.ERROR; changed(); });
            }
        });
    }
    void verify(Consumer<File> success, Runnable failure) {
        if (phase != Phase.READY || update == null || apk == null) { failure.run(); return; }
        UpdateClient.Update expected = update; File file = apk;
        executor.execute(() -> {
            try {
                client.verifyReady(file, expected);
                main.post(() -> success.accept(file));
            } catch (Exception error) {
                main.post(() -> { update = null; apk = null; phase = Phase.ERROR; changed(); failure.run(); });
            }
        });
    }
}
