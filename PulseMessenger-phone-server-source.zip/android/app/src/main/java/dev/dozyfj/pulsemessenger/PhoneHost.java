package dev.dozyfj.pulsemessenger;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

final class PhoneHost {
    enum Phase { STOPPED, STARTING, RUNNING, STOPPING, ERROR }
    private static PhoneHost instance;
    static synchronized PhoneHost get(Context context) {
        if (instance == null) instance = new PhoneHost(context.getApplicationContext());
        return instance;
    }
    private final Context context;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Set<Runnable> listeners = new LinkedHashSet<>();
    private PhoneServerService service;
    private Phase phase = Phase.STOPPED;
    private String fingerprint = "";
    private int port;
    private PhoneHost(Context context) { this.context = context; }
    Phase phase() { return phase; }
    void bind(Runnable listener) { listeners.add(listener); listener.run(); }
    void unbind(Runnable listener) { listeners.remove(listener); }
    private void changed() { for (Runnable listener : new ArrayList<>(listeners)) listener.run(); }
    void start() {
        if (phase != Phase.STOPPED && phase != Phase.ERROR) return;
        phase = Phase.STARTING; changed();
        try { context.startForegroundService(new Intent(context, PhoneServerService.class)); }
        catch (RuntimeException error) { phase = Phase.ERROR; changed(); }
    }
    void stop() {
        if (phase != Phase.RUNNING && phase != Phase.STARTING) return;
        phase = Phase.STOPPING; changed();
        context.stopService(new Intent(context, PhoneServerService.class));
    }
    void attach(PhoneServerService owner) { service = owner; phase = Phase.STARTING; changed(); }
    void running(PhoneServerService owner, String pin, int actualPort) {
        main.post(() -> {
            if (service != owner || phase == Phase.STOPPING) return;
            fingerprint = pin; port = actualPort; phase = Phase.RUNNING; changed();
        });
    }
    void failed(PhoneServerService owner) {
        main.post(() -> { if (service == owner) { phase = Phase.ERROR; changed(); owner.stopSelf(); } });
    }
    void stopping(PhoneServerService owner) {
        if (service == owner && phase != Phase.ERROR) { phase = Phase.STOPPING; changed(); }
    }
    void stopped(PhoneServerService owner) {
        main.post(() -> {
            if (service != owner) return;
            service = null; fingerprint = "";
            if (phase != Phase.ERROR) phase = Phase.STOPPED;
            changed();
        });
    }
    String localUrl() { return phase == Phase.RUNNING ? url("127.0.0.1") : ""; }
    private String url(String address) { return "https://" + address + ":" + port + "#sha256=" + fingerprint; }
    List<String> lanUrls() {
        if (phase != Phase.RUNNING) return Collections.emptyList();
        List<String> result = new ArrayList<>();
        try {
            for (NetworkInterface network : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!network.isUp() || network.isLoopback()) continue;
                for (InetAddress address : Collections.list(network.getInetAddresses()))
                    if (address instanceof Inet4Address && address.isSiteLocalAddress()) result.add(url(address.getHostAddress()));
            }
        } catch (Exception ignored) { }
        return result;
    }
}
