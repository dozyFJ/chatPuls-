package dev.dozyfj.pulsemessenger;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.security.MessageDigest;
import java.security.SecureRandom;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/** Server accounts are separate from the client's local notes and offline queue. */
final class PhoneServerStore extends SQLiteOpenHelper {
    private static final SecureRandom RANDOM = new SecureRandom();
    PhoneServerStore(Context context) { super(context.getApplicationContext(), "pulse-host.db", null, 1); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users (name TEXT PRIMARY KEY, salt TEXT NOT NULL, password TEXT NOT NULL)");
        db.execSQL("CREATE TABLE sessions (hash TEXT PRIMARY KEY, username TEXT NOT NULL, expires INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE messages (sequence INTEGER PRIMARY KEY AUTOINCREMENT, id TEXT NOT NULL, sender TEXT NOT NULL, recipient TEXT NOT NULL, body TEXT NOT NULL, created INTEGER NOT NULL, UNIQUE(sender,id))");
        db.execSQL("CREATE INDEX messages_sender ON messages(sender,sequence)");
        db.execSQL("CREATE INDEX messages_recipient ON messages(recipient,sequence)");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { throw new IllegalStateException("Unsupported host database version"); }
    static String hex(byte[] bytes) {
        StringBuilder out = new StringBuilder();
        for (byte b : bytes) out.append(String.format(java.util.Locale.ROOT, "%02x", b & 255));
        return out.toString();
    }
    private static String random(int size) { byte[] bytes = new byte[size]; RANDOM.nextBytes(bytes); return hex(bytes); }
    static String hash(String text) throws Exception { return hex(MessageDigest.getInstance("SHA-256").digest(text.getBytes(java.nio.charset.StandardCharsets.UTF_8))); }
    private static String derive(String password, String salt) throws Exception {
        PBEKeySpec key = new PBEKeySpec(password.toCharArray(), salt.getBytes(java.nio.charset.StandardCharsets.UTF_8), 120_000, 256);
        try { return hex(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(key).getEncoded()); }
        finally { key.clearPassword(); }
    }
    private static boolean validName(String value) {
        return value.matches("[a-z0-9_]{3,32}") && !value.equals("__proto__") && !value.equals("constructor") && !value.equals("prototype");
    }
    static final class Failure extends Exception {
        final int status;
        Failure(int status) { this.status = status; }
    }
    synchronized JSONObject authenticate(JSONObject input, boolean register) throws Exception {
        Object rawName = input.opt("username"), rawPassword = input.opt("password");
        if (!(rawName instanceof String) || !(rawPassword instanceof String)) throw new Failure(400);
        String name = ((String) rawName).trim().toLowerCase(java.util.Locale.ROOT), password = (String) rawPassword;
        if (!validName(name) || password.length() < 10 || password.length() > 128) throw new Failure(400);
        SQLiteDatabase db = getWritableDatabase();
        String salt = null, expected = null;
        try (Cursor c = db.rawQuery("SELECT salt,password FROM users WHERE name = ?", new String[]{name})) {
            if (c.moveToFirst()) { salt = c.getString(0); expected = c.getString(1); }
        }
        if (register) {
            if (salt != null) throw new Failure(409);
            salt = random(16);
            ContentValues user = new ContentValues(); user.put("name", name); user.put("salt", salt); user.put("password", derive(password, salt));
            db.insertOrThrow("users", null, user);
        } else {
            String actual = derive(password, salt == null ? "00000000000000000000000000000000" : salt);
            if (expected == null || !MessageDigest.isEqual(actual.getBytes(java.nio.charset.StandardCharsets.US_ASCII), expected.getBytes(java.nio.charset.StandardCharsets.US_ASCII))) throw new Failure(401);
        }
        String token = random(32);
        db.delete("sessions", "expires <= ?", new String[]{Long.toString(System.currentTimeMillis())});
        ContentValues session = new ContentValues(); session.put("hash", hash(token)); session.put("username", name); session.put("expires", System.currentTimeMillis() + 30L * 24 * 60 * 60 * 1000);
        db.insertOrThrow("sessions", null, session);
        return new JSONObject().put("username", name).put("token", token);
    }
    synchronized String user(String authorization) throws Exception {
        if (authorization == null || !authorization.matches("Bearer [a-f0-9]{64}")) throw new Failure(401);
        try (Cursor c = getReadableDatabase().rawQuery("SELECT username FROM sessions WHERE hash = ? AND expires > ?", new String[]{hash(authorization.substring(7)), Long.toString(System.currentTimeMillis())})) {
            if (c.moveToFirst()) return c.getString(0);
        }
        throw new Failure(401);
    }
    private JSONObject message(Cursor c) throws Exception {
        return new JSONObject().put("sequence", c.getLong(0)).put("id", c.getString(1)).put("from", c.getString(2)).put("to", c.getString(3)).put("text", c.getString(4)).put("time", c.getLong(5));
    }
    synchronized JSONObject fetch(String user, String after) throws Exception {
        if (!after.matches("[0-9]{1,15}")) throw new Failure(400);
        JSONArray messages = new JSONArray();
        try (Cursor c = getReadableDatabase().rawQuery("SELECT sequence,id,sender,recipient,body,created FROM messages WHERE sequence > ? AND (sender = ? OR recipient = ?) ORDER BY sequence LIMIT 100", new String[]{after, user, user})) {
            while (c.moveToNext()) messages.put(message(c));
        }
        return new JSONObject().put("messages", messages);
    }
    synchronized JSONObject send(String user, JSONObject input) throws Exception {
        Object rawTo = input.opt("to"), rawId = input.opt("id"), rawText = input.opt("text");
        if (!(rawTo instanceof String) || !(rawId instanceof String) || !(rawText instanceof String)) throw new Failure(400);
        String to = ((String) rawTo).trim().toLowerCase(java.util.Locale.ROOT), id = (String) rawId, text = (String) rawText;
        if (!validName(to) || to.equals(user) || !id.matches("[a-f0-9-]{36}") || text.trim().isEmpty() || text.length() > 2000) throw new Failure(400);
        SQLiteDatabase db = getWritableDatabase();
        try (Cursor c = db.rawQuery("SELECT name FROM users WHERE name = ?", new String[]{to})) { if (!c.moveToFirst()) throw new Failure(404); }
        try (Cursor c = db.rawQuery("SELECT sequence,id,sender,recipient,body,created FROM messages WHERE sender = ? AND id = ?", new String[]{user, id})) {
            if (c.moveToFirst()) {
                JSONObject existing = message(c);
                if (!to.equals(existing.getString("to")) || !text.equals(existing.getString("text"))) throw new Failure(409);
                return existing;
            }
        }
        ContentValues values = new ContentValues(); values.put("id", id); values.put("sender", user); values.put("recipient", to); values.put("body", text); values.put("created", System.currentTimeMillis());
        long sequence = db.insertOrThrow("messages", null, values);
        return new JSONObject().put("sequence", sequence).put("id", id).put("from", user).put("to", to).put("text", text).put("time", values.getAsLong("created"));
    }
}
